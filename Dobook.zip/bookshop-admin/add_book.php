<?php
require_once 'config.php';
require_admin();

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0) ?: null;
    $price = (float)($_POST['price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $section = $_POST['section'] ?? 'none';

    if ($title === '' || $author === '' || $price <= 0) {
        $error = 'Judul, penulis, dan harga wajib diisi dengan benar.';
    } else {
        $imageName = 'no-image.png';

        if (!empty($_FILES['image']['name'])) {
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','webp'];
            if (in_array($ext, $allowed) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $imageName = 'book_' . time() . '_' . rand(1000,9999) . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], UPLOAD_DIR . $imageName);
            } else {
                $error = 'Format gambar harus jpg, jpeg, png, atau webp.';
            }
        }

        if (!$error) {
            $stmt = $pdo->prepare("INSERT INTO books (title, author, category_id, price, stock, description, image, section) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->execute([$title, $author, $category_id, $price, $stock, $description, $imageName, $section]);
            flash('success', 'Buku "' . $title . '" berhasil ditambahkan.');
            header('Location: ' . BASE_URL . '/books.php');
            exit;
        }
    }
}

$page_title = 'Tambah Buku';
require_once 'includes/header.php';
?>

<h1>Tambah Buku</h1>

<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" style="background:#fff;padding:24px;border-radius:10px;border:1px solid #e4e4e4;max-width:600px;">
  <div class="form-group">
    <label>Judul Buku</label>
    <input type="text" name="title" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
  </div>
  <div class="form-group">
    <label>Penulis</label>
    <input type="text" name="author" required value="<?= htmlspecialchars($_POST['author'] ?? '') ?>">
  </div>
  <div class="form-group">
    <label>Kategori</label>
    <select name="category_id">
      <option value="">-- Pilih Kategori --</option>
      <?php foreach ($categories as $c): ?>
        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div style="display:flex;gap:12px;">
    <div class="form-group" style="flex:1;">
      <label>Harga (Rp)</label>
      <input type="number" name="price" min="0" step="1" required value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
    </div>
    <div class="form-group" style="flex:1;">
      <label>Stok</label>
      <input type="number" name="stock" min="0" required value="<?= htmlspecialchars($_POST['stock'] ?? '') ?>">
    </div>
  </div>
  <div class="form-group">
    <label>Tampil di Section</label>
    <select name="section">
      <option value="none">Tidak ditampilkan di beranda</option>
      <option value="new">What's New</option>
      <option value="bestseller">Best Seller</option>
      <option value="trending">Trending Now</option>
    </select>
  </div>
  <div class="form-group">
    <label>Deskripsi</label>
    <textarea name="description" rows="4"><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
  </div>
  <div class="form-group">
    <label>Cover Buku</label>
    <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
  </div>
  <button type="submit" class="btn btn-primary">Simpan Buku</button>
  <a href="<?= BASE_URL ?>/books.php" class="btn btn-outline">Batal</a>
</form>

<?php require_once 'includes/footer.php'; ?>
