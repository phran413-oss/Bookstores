<?php
require_once 'config.php';

if (is_admin()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Email dan password wajib diisi.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        // hanya akun dengan role admin yang boleh masuk lewat web admin
        if ($user && $user['role'] === 'admin' && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            header('Location: ' . BASE_URL . '/index.php');
            exit;
        } else {
            $error = 'Email atau password admin salah.';
        }
    }
}

$covers = random_covers($pdo);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Admin <?= SITE_NAME ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Young+Serif&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<main class="container">
<div class="auth">
  <div class="auth-side">
    <div>
      <h2>Panel admin <?= SITE_NAME ?>.</h2>
      <p>Kelola buku, stok, dan pesanan toko dari satu tempat.</p>
    </div>
    <div class="fan">
      <?php foreach ($covers as $c): ?><img src="<?= book_image_url($c['image']) ?>" alt=""><?php endforeach; ?>
    </div>
  </div>
  <div class="auth-form">
    <h1>Admin log in</h1>
    <?php if ($error): ?>
      <div class="alert alert-error" role="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post">
      <div class="form-group">
        <label for="email">Email</label>
        <input id="email" type="email" name="email" required autocomplete="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input id="password" type="password" name="password" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn btn-primary btn-block">Log in</button>
    </form>
    <p class="auth-alt"><a href="<?= STORE_URL ?>/index.php">&larr; Kembali ke toko</a></p>
  </div>
</div>
</main>
</body>
</html>
