<?php
require_once 'config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    $img = null;
    $stmt = $pdo->prepare("SELECT image FROM books WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if ($row) $img = $row['image'];

    $pdo->prepare("DELETE FROM books WHERE id = ?")->execute([$id]);

    if ($img && $img !== 'no-image.png' && file_exists(UPLOAD_DIR . $img)) {
        @unlink(UPLOAD_DIR . $img);
    }
    flash('success', 'Buku berhasil dihapus.');
    header('Location: ' . BASE_URL . '/books.php');
    exit;
}

$q = trim($_GET['q'] ?? '');
$sql = "SELECT b.*, c.name AS category_name FROM books b LEFT JOIN categories c ON b.category_id = c.id";
$params = [];
if ($q !== '') {
    $sql .= " WHERE b.title LIKE ? OR b.author LIKE ?";
    $params[] = "%$q%";
    $params[] = "%$q%";
}
$sql .= " ORDER BY b.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$page_title = 'Kelola Buku';
require_once 'includes/header.php';
?>

<div class="admin-topbar">
  <h1 style="margin:0;">Kelola Buku</h1>
  <a href="<?= BASE_URL ?>/add_book.php" class="btn btn-primary">+ Tambah Buku</a>
</div>

<form method="get" style="margin-bottom:16px;max-width:320px;">
  <input type="text" name="q" placeholder="Cari judul / penulis..." value="<?= htmlspecialchars($q) ?>" style="width:100%;padding:8px 12px;border-radius:6px;border:1px solid #ddd;">
</form>

<?php if (empty($books)): ?>
  <div class="empty">Belum ada buku. <a href="<?= BASE_URL ?>/add_book.php">Tambah buku pertama</a></div>
<?php else: ?>
  <table class="data-table">
    <thead><tr><th>Cover</th><th>Judul</th><th>Penulis</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Section</th><th>Aksi</th></tr></thead>
    <tbody>
    <?php foreach ($books as $b): ?>
      <tr>
        <td><img src="<?= book_image_url($b['image']) ?>" style="width:36px;height:50px;object-fit:cover;border-radius:4px;"></td>
        <td><?= htmlspecialchars($b['title']) ?></td>
        <td><?= htmlspecialchars($b['author']) ?></td>
        <td><?= htmlspecialchars($b['category_name'] ?? '-') ?></td>
        <td><?= rupiah($b['price']) ?></td>
        <td><?= $b['stock'] ?></td>
        <td><?= $b['section'] ?></td>
        <td style="white-space:nowrap;">
          <a href="<?= BASE_URL ?>/edit_book.php?id=<?= $b['id'] ?>" class="btn btn-outline" style="padding:5px 10px;font-size:12px;">Edit</a>
          <form method="post" style="display:inline;" onsubmit="return confirm('Hapus buku ini?');">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= $b['id'] ?>">
            <button type="submit" class="btn btn-danger" style="padding:5px 10px;font-size:12px;">Hapus</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
