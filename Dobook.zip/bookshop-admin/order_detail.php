<?php
require_once 'config.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newStatus = $_POST['status'] ?? '';
    $allowed = ['pending','paid','shipped','completed','cancelled'];

    $stmt = $pdo->prepare("SELECT status FROM orders WHERE id = ?");
    $stmt->execute([$id]);
    $cur = $stmt->fetchColumn();

    if ($cur === false || !in_array($newStatus, $allowed, true)) {
        // abaikan permintaan yang tidak valid
    } elseif ($cur === 'cancelled') {
        flash('error', 'Pesanan yang sudah dibatalkan tidak bisa diubah statusnya.');
    } elseif ($cur !== $newStatus) {
        try {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
            if ($newStatus === 'cancelled') {
                // kembalikan stok yang sudah dikurangi saat pesanan dibuat
                $pdo->prepare("UPDATE books b JOIN order_items oi ON oi.book_id = b.id SET b.stock = b.stock + oi.quantity WHERE oi.order_id = ?")->execute([$id]);
            }
            $pdo->commit();

            if ($cur === 'pending' && $newStatus === 'paid') {
                flash('success', 'Pembayaran dikonfirmasi. Pesanan siap diproses.');
            } elseif ($newStatus === 'cancelled') {
                flash('success', 'Pesanan dibatalkan dan stok buku dikembalikan.');
            } else {
                flash('success', 'Status pesanan diperbarui.');
            }
        } catch (Exception $e) {
            $pdo->rollBack();
            flash('error', 'Gagal memperbarui status, silakan coba lagi.');
        }
    }
    header('Location: ' . BASE_URL . '/order_detail.php?id=' . $id);
    exit;
}

$stmt = $pdo->prepare("SELECT o.*, u.name AS customer, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: ' . BASE_URL . '/orders.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->execute([$id]);
$items = $stmt->fetchAll();

$page_title = 'Detail Pesanan';
require_once 'includes/header.php';
?>

<h1>Detail Pesanan #<?= htmlspecialchars($order['receipt_no']) ?></h1>

<div style="display:flex;gap:20px;flex-wrap:wrap;">
  <div style="flex:2;min-width:300px;">
    <table class="data-table" style="margin-bottom:20px;">
      <thead><tr><th>Buku</th><th>Harga</th><th>Qty</th><th>Subtotal</th></tr></thead>
      <tbody>
      <?php foreach ($items as $it): ?>
        <tr>
          <td><?= htmlspecialchars($it['title']) ?></td>
          <td><?= rupiah($it['price']) ?></td>
          <td><?= $it['quantity'] ?></td>
          <td><?= rupiah($it['subtotal']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <a href="<?= BASE_URL ?>/receipt.php?order_id=<?= $order['id'] ?>" class="btn btn-outline" target="_blank">Lihat Struk</a>

    <div class="cart-summary" style="margin-top:20px;">
      <h3 style="margin-top:0;">Bukti pembayaran</h3>
      <?php if (!empty($order['payment_proof'])): ?>
        <a href="<?= PROOF_URL . htmlspecialchars($order['payment_proof']) ?>" target="_blank" rel="noopener">
          <img class="proof-img" src="<?= PROOF_URL . htmlspecialchars($order['payment_proof']) ?>" alt="Bukti pembayaran <?= htmlspecialchars($order['receipt_no']) ?>">
        </a>
        <p class="muted" style="margin:10px 0 0;font-size:.85rem;">Klik gambar untuk memperbesar. Pastikan nominalnya <?= rupiah($order['total']) ?>.</p>
      <?php elseif ($order['payment_method'] === 'Bayar di Tempat (COD)'): ?>
        <p class="muted" style="margin:0;">Metode COD, tidak ada bukti pembayaran.</p>
      <?php else: ?>
        <p class="muted" style="margin:0;">Tidak ada bukti pembayaran (pesanan dibuat sebelum fitur ini ada).</p>
      <?php endif; ?>
    </div>
  </div>

  <div style="flex:1;min-width:260px;">
    <div class="cart-summary" style="margin-bottom:16px;">
      <h3 style="margin-top:0;">Informasi</h3>
      <p><strong>Customer:</strong> <?= htmlspecialchars($order['customer']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
      <?php if (!empty($order['address'])): ?>
        <p><strong>Penerima:</strong> <?= htmlspecialchars($order['recipient_name']) ?></p>
        <p><strong>Telepon:</strong> <?= htmlspecialchars($order['phone']) ?></p>
        <p><strong>Alamat:</strong><br><?= nl2br(htmlspecialchars($order['address'])) ?></p>
      <?php else: ?>
        <p><strong>Alamat:</strong> <span class="muted">Tidak tercatat (pesanan lama)</span></p>
      <?php endif; ?>
      <p><strong>Tanggal:</strong> <?= date('d M Y, H:i', strtotime($order['order_date'])) ?></p>
      <p><strong>Pembayaran:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
      <p><strong>Total:</strong> <?= rupiah($order['total']) ?></p>
      <p style="margin-bottom:0;"><strong>Status:</strong> <span class="status-tag status-<?= htmlspecialchars($order['status']) ?>"><?= status_label($order['status']) ?></span></p>
    </div>

    <?php if ($order['status'] === 'pending'): ?>
    <form method="post" class="cart-summary" style="margin-bottom:16px;">
      <h3 style="margin-top:0;">Verifikasi pembayaran</h3>
      <p class="muted" style="margin-top:0;">Cek bukti pembayaran di sebelah kiri. Menolak akan membatalkan pesanan dan mengembalikan stok buku.</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <button type="submit" name="status" value="paid" class="btn btn-primary">Konfirmasi pembayaran</button>
        <button type="submit" name="status" value="cancelled" class="btn btn-danger" onclick="return confirm('Tolak dan batalkan pesanan ini? Stok buku akan dikembalikan.');">Tolak &amp; batalkan</button>
      </div>
    </form>
    <?php endif; ?>

    <?php if ($order['status'] === 'cancelled'): ?>
      <div class="cart-summary">
        <h3 style="margin-top:0;">Update Status</h3>
        <p class="muted" style="margin:0;">Pesanan ini sudah dibatalkan, statusnya tidak dapat diubah lagi.</p>
      </div>
    <?php else: ?>
    <form method="post" class="cart-summary">
      <h3 style="margin-top:0;">Update Status</h3>
      <div class="form-group">
        <select name="status">
          <?php foreach (['pending','paid','shipped','completed','cancelled'] as $s): ?>
            <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= status_label($s) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Simpan Status</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
