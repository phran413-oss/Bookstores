<?php
$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - Admin ' . SITE_NAME : 'Admin ' . SITE_NAME ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Young+Serif&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<?php require_once __DIR__ . '/../../includes/icons.php'; ?>
<div class="admin-wrap">
  <nav class="admin-sidebar" aria-label="Menu admin">
    <div class="logo"><span style="display:flex;align-items:center;gap:9px;"><span class="logo-mark"></span><?= SITE_NAME ?></span><small>Panel admin</small></div>
    <a class="side <?= $current === 'index.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/index.php"><?= icon('grid') ?>Dashboard</a>
    <a class="side <?= in_array($current, ['books.php','add_book.php','edit_book.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/books.php"><?= icon('book') ?>Kelola Buku</a>
    <a class="side <?= in_array($current, ['orders.php','order_detail.php']) ? 'active' : '' ?>" href="<?= BASE_URL ?>/admin/orders.php"><?= icon('receipt') ?>Kelola Pesanan</a>
    <hr>
    <a class="side" href="<?= BASE_URL ?>/index.php"><?= icon('store') ?>Lihat Toko</a>
    <a class="side" href="<?= BASE_URL ?>/logout.php"><?= icon('logout') ?>Log out</a>
  </nav>
  <div class="admin-main">
    <?php if ($m = flash('success')): ?><div class="alert alert-success" role="status"><?= htmlspecialchars($m) ?></div><?php endif; ?>
    <?php if ($m = flash('error')): ?><div class="alert alert-error" role="alert"><?= htmlspecialchars($m) ?></div><?php endif; ?>
