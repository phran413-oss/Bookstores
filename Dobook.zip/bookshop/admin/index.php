<?php
require_once '../config.php';
require_admin();

$totalBooks = $pdo->query("SELECT COUNT(*) c FROM books")->fetch()['c'];
$totalUsers = $pdo->query("SELECT COUNT(*) c FROM users WHERE role='user'")->fetch()['c'];
$totalOrders = $pdo->query("SELECT COUNT(*) c FROM orders")->fetch()['c'];
$totalRevenue = $pdo->query("SELECT COALESCE(SUM(total),0) t FROM orders WHERE status != 'cancelled'")->fetch()['t'];
$lowStock = $pdo->query("SELECT COUNT(*) c FROM books WHERE stock <= 5")->fetch()['c'];

$recentOrders = $pdo->query("SELECT o.*, u.name AS customer FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.order_date DESC LIMIT 8")->fetchAll();

$page_title = 'Dashboard';
require_once 'includes/header.php';
?>

<div class="admin-topbar">
  <h1 style="margin:0;">Dashboard</h1>
  <a href="<?= BASE_URL ?>/admin/add_book.php" class="btn btn-primary">+ Tambah Buku</a>
</div>

<div class="stat-cards">
  <div class="stat-card"><div class="num"><?= $totalBooks ?></div><div class="label">Total Buku</div></div>
  <div class="stat-card"><div class="num"><?= $totalUsers ?></div><div class="label">Total User</div></div>
  <div class="stat-card"><div class="num"><?= $totalOrders ?></div><div class="label">Total Transaksi</div></div>
  <div class="stat-card"><div class="num"><?= rupiah($totalRevenue) ?></div><div class="label">Total Pendapatan</div></div>
  <div class="stat-card"><div class="num" style="color:<?= $lowStock > 0 ? '#c0392b' : '#127a3e' ?>;"><?= $lowStock ?></div><div class="label">Buku Stok Menipis (≤5)</div></div>
</div>

<h3>Transaksi Terbaru</h3>
<?php if (empty($recentOrders)): ?>
  <div class="empty">Belum ada transaksi.</div>
<?php else: ?>
  <table class="data-table">
    <thead><tr><th>Invoice</th><th>Customer</th><th>Tanggal</th><th>Total</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($recentOrders as $o): ?>
      <tr>
        <td><?= htmlspecialchars($o['receipt_no']) ?></td>
        <td><?= htmlspecialchars($o['customer']) ?></td>
        <td><?= date('d M Y, H:i', strtotime($o['order_date'])) ?></td>
        <td><?= rupiah($o['total']) ?></td>
        <td><span class="status-tag status-<?= $o['status'] ?>"><?= status_label($o['status']) ?></span></td>
        <td><a href="<?= BASE_URL ?>/admin/order_detail.php?id=<?= $o['id'] ?>" class="btn btn-outline" style="padding:6px 12px;font-size:12px;">Detail</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
