<?php
require_once '../config.php';
require_admin();

$status = $_GET['status'] ?? '';
$sql = "SELECT o.*, u.name AS customer, u.email FROM orders o JOIN users u ON o.user_id = u.id";
$params = [];
if ($status !== '') {
    $sql .= " WHERE o.status = ?";
    $params[] = $status;
}
$sql .= " ORDER BY o.order_date DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

$page_title = 'Kelola Pesanan';
require_once 'includes/header.php';
?>

<h1>Kelola Pesanan</h1>

<div class="tabs">
  <a href="<?= BASE_URL ?>/admin/orders.php" class="<?= $status === '' ? 'active' : '' ?>">Semua</a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=paid" class="<?= $status === 'paid' ? 'active' : '' ?>">Paid</a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=shipped" class="<?= $status === 'shipped' ? 'active' : '' ?>">Shipped</a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=completed" class="<?= $status === 'completed' ? 'active' : '' ?>">Completed</a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=cancelled" class="<?= $status === 'cancelled' ? 'active' : '' ?>">Cancelled</a>
</div>

<?php if (empty($orders)): ?>
  <div class="empty">Tidak ada transaksi.</div>
<?php else: ?>
  <table class="data-table">
    <thead><tr><th>Invoice</th><th>Customer</th><th>Email</th><th>Tanggal</th><th>Total</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($orders as $o): ?>
      <tr>
        <td><?= htmlspecialchars($o['receipt_no']) ?></td>
        <td><?= htmlspecialchars($o['customer']) ?></td>
        <td><?= htmlspecialchars($o['email']) ?></td>
        <td><?= date('d M Y, H:i', strtotime($o['order_date'])) ?></td>
        <td><?= rupiah($o['total']) ?></td>
        <td><span class="status-tag status-<?= $o['status'] ?>"><?= status_label($o['status']) ?></span></td>
        <td><a href="<?= BASE_URL ?>/admin/order_detail.php?id=<?= $o['id'] ?>" class="btn btn-outline" style="padding:6px 12px;font-size:12px;">Detail</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
