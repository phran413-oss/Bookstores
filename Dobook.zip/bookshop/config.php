<?php
// ============================================
// KONFIGURASI DATABASE & SESSION
// ============================================
// BASE_URL harus didefinisikan sebelum session_start (dipakai untuk path cookie)
define('BASE_URL', '/bookshop'); // ganti jika nama folder di htdocs berbeda

// Web toko (user) punya sesi sendiri, terpisah dari web admin (/bookshop-admin).
session_name('BOOKSHOP_USER');
session_set_cookie_params([
    'path'     => BASE_URL,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

$DB_HOST = 'localhost';
$DB_NAME = 'bookshop';
$DB_USER = 'root';
$DB_PASS = ''; // default XAMPP kosong

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Koneksi database gagal. Pastikan XAMPP (Apache & MySQL) aktif dan database 'bookshop' sudah di-import. Detail: " . $e->getMessage());
}

define('UPLOAD_DIR', __DIR__ . '/assets/images/uploads/');
define('UPLOAD_URL', BASE_URL . '/assets/images/uploads/');
define('SITE_NAME', 'Dobook'); // ganti nama toko di sini

// ---- Info pembayaran (ganti sesuai toko) ----
define('BANK_NAME', 'BCA');
define('BANK_ACCOUNT_NO', '1234567890');
define('BANK_ACCOUNT_NAME', 'Dobook Store');
define('QRIS_FILE', 'assets/images/qris.png');              // taruh gambar QRIS di sini
define('PROOF_DIR', __DIR__ . '/assets/images/proofs/');    // folder bukti pembayaran dari pembeli

// ============================================
// HELPER FUNCTIONS
// ============================================

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function rupiah($num) {
    return 'Rp' . number_format($num, 0, ',', '.');
}

function book_image_url($image) {
    if (empty($image) || $image === 'no-image.png') {
        return BASE_URL . '/assets/images/no-image.png';
    }
    return UPLOAD_URL . $image;
}

function cart_count($pdo) {
    if (!is_logged_in()) return 0;
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(quantity),0) AS c FROM cart WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return (int) $stmt->fetch()['c'];
}

function flash($key, $msg = null) {
    if ($msg !== null) {
        $_SESSION['flash'][$key] = $msg;
        return;
    }
    if (isset($_SESSION['flash'][$key])) {
        $val = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $val;
    }
    return null;
}

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_check($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token ?? '');
}

// ============================================
// HELPER TAMPILAN (UI)
// ============================================

function icon($name, $extra = '') {
    return '<svg class="ic ' . $extra . '" aria-hidden="true"><use href="#i-' . $name . '"/></svg>';
}

function status_label($status) {
    $map = [
        'pending'   => 'Menunggu konfirmasi',
        'paid'      => 'Lunas',
        'shipped'   => 'Dikirim',
        'completed' => 'Selesai',
        'cancelled' => 'Dibatalkan',
    ];
    return $map[$status] ?? ucfirst($status);
}

function wish_ids($pdo) {
    if (!is_logged_in()) return [];
    $stmt = $pdo->prepare("SELECT book_id FROM wishlist WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return array_column($stmt->fetchAll(), 'book_id');
}

function random_covers($pdo, $n = 3) {
    $n = (int)$n;
    return $pdo->query("SELECT image FROM books WHERE image <> 'no-image.png' AND image <> '' ORDER BY RAND() LIMIT $n")->fetchAll();
}

// Kartu buku (dipakai di beranda, daftar buku, wishlist, detail)
function render_book_card($b, $wishIds) {
    $isWished = in_array($b['id'], $wishIds);
    $url = BASE_URL . '/book_detail.php?id=' . $b['id'];
    $title = htmlspecialchars($b['title']);
    echo '<article class="book">';
    echo '<a class="cover" href="' . $url . '"><img src="' . book_image_url($b['image']) . '" alt="Sampul ' . $title . '" loading="lazy">';
    echo '</a>';
    echo '<button type="button" class="wish' . ($isWished ? ' active' : '') . '" data-wish="' . $b['id'] . '" aria-pressed="' . ($isWished ? 'true' : 'false') . '" aria-label="Simpan ke wishlist">' . icon('bookmark') . '</button>';
    echo '<div class="book-meta">';
    echo '<a class="book-title" href="' . $url . '">' . $title . '</a>';
    echo '<p class="book-author">' . htmlspecialchars($b['author']) . '</p>';
    echo '<div class="price"><strong>' . rupiah($b['price']) . '</strong></div>';
    echo '<form method="post" action="' . BASE_URL . '/cart.php">';
    echo '<input type="hidden" name="book_id" value="' . $b['id'] . '"><input type="hidden" name="action" value="add">';
    if ($b['stock'] > 0) {
        echo '<button type="submit" class="btn btn-ghost btn-sm">Tambah ke keranjang</button>';
    } else {
        echo '<button type="button" class="btn btn-ghost btn-sm" disabled>Stok habis</button>';
    }
    echo '</form></div></article>';
}
