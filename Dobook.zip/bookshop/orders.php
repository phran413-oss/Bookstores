<?php
require_once 'config.php';
require_login();

$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC");
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();

$page_title = 'Pesanan Saya';
require_once 'includes/header.php';
?>

<div class="page-head">
  <h1>Pesanan saya</h1>
  <p>Riwayat belanja dan struk pembayaranmu.</p>
</div>

<?php if (empty($orders)): ?>
  <div class="empty">
    <p>Kamu belum punya pesanan.</p>
    <a href="<?= BASE_URL ?>/category.php" class="btn btn-primary">Mulai belanja</a>
  </div>
<?php else: ?>
  <div class="orders">
    <?php foreach ($orders as $o): ?>
    <div class="order">
      <div><span class="inv"><?= htmlspecialchars($o['receipt_no']) ?></span><small><?= date('d M Y, H:i', strtotime($o['order_date'])) ?></small></div>
      <div class="muted"><?= htmlspecialchars($o['payment_method']) ?></div>
      <div><strong><?= rupiah($o['total']) ?></strong></div>
      <div><span class="status-tag status-<?= htmlspecialchars($o['status']) ?>"><?= status_label($o['status']) ?></span></div>
      <div><a href="<?= BASE_URL ?>/receipt.php?order_id=<?= $o['id'] ?>" class="btn btn-outline btn-sm">Lihat struk</a></div>
    </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
