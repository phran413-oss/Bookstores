<?php
require_once 'config.php';
require_login();

// ===== AJAX: toggle wishlist =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle') {
    header('Content-Type: application/json');
    $bookId = (int)($_POST['book_id'] ?? 0);

    $stmt = $pdo->prepare("SELECT id FROM wishlist WHERE user_id = ? AND book_id = ?");
    $stmt->execute([$_SESSION['user_id'], $bookId]);
    $existing = $stmt->fetch();

    if ($existing) {
        $pdo->prepare("DELETE FROM wishlist WHERE id = ?")->execute([$existing['id']]);
        echo json_encode(['wished' => false]);
    } else {
        $pdo->prepare("INSERT INTO wishlist (user_id, book_id) VALUES (?,?)")->execute([$_SESSION['user_id'], $bookId]);
        echo json_encode(['wished' => true]);
    }
    exit;
}

// ===== Remove via normal form (fallback) =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'remove') {
    $bookId = (int)($_POST['book_id'] ?? 0);
    $pdo->prepare("DELETE FROM wishlist WHERE user_id = ? AND book_id = ?")->execute([$_SESSION['user_id'], $bookId]);
    header('Location: ' . BASE_URL . '/wishlist.php');
    exit;
}

$stmt = $pdo->prepare("SELECT b.* FROM wishlist w JOIN books b ON w.book_id = b.id WHERE w.user_id = ? ORDER BY w.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$books = $stmt->fetchAll();

$page_title = 'Wishlist';
require_once 'includes/header.php';
?>

<div class="page-head">
  <h1>Wishlist saya</h1>
  <p>Buku yang kamu simpan untuk dibaca atau dibeli nanti.</p>
</div>

<?php if (empty($books)): ?>
  <div class="empty">
    <p>Belum ada buku di wishlist. Tekan ikon pembatas buku di sampul untuk menyimpan.</p>
    <a href="<?= BASE_URL ?>/category.php" class="btn btn-primary">Cari buku</a>
  </div>
<?php else: ?>
  <div class="book-grid" data-wishlist-page>
    <?php $wishIds = array_column($books, 'id'); foreach ($books as $b) render_book_card($b, $wishIds); ?>
  </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
