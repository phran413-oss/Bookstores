<?php
require_once 'config.php';
require_login();

$userId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT c.quantity, b.* FROM cart c JOIN books b ON c.book_id = b.id WHERE c.user_id = ?");
$stmt->execute([$userId]);
$items = $stmt->fetchAll();

if (empty($items)) {
    header('Location: ' . BASE_URL . '/cart.php');
    exit;
}

$subtotal = 0;
foreach ($items as $it) {
    $subtotal += $it['price'] * $it['quantity'];
}
$shipping = 15000;
$grandTotal = $subtotal + $shipping;

$payMethods   = ['Transfer Bank', 'QRIS', 'Bayar di Tempat (COD)'];
$proofMethods = ['Transfer Bank', 'QRIS']; // metode yang wajib unggah bukti

// cek file bukti pembayaran: harus gambar asli (JPG/PNG/WEBP), maks. 2 MB
function check_payment_proof($f) {
    if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return 'Unggah bukti pembayaran terlebih dahulu.';
    }
    if ($f['error'] !== UPLOAD_ERR_OK) {
        return 'Upload bukti pembayaran gagal, silakan coba lagi.';
    }
    if ($f['size'] > 2 * 1024 * 1024) {
        return 'Ukuran bukti pembayaran maksimal 2 MB.';
    }
    $info = @getimagesize($f['tmp_name']);
    if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) {
        return 'Bukti pembayaran harus berupa gambar JPG, PNG, atau WEBP.';
    }
    return null;
}

$error = null;
$payment = 'Transfer Bank';
// isi awal form: nama diambil dari akun, sisanya kosong
$form = [
    'recipient_name' => $_SESSION['name'] ?? '',
    'phone'          => '',
    'address'        => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment = $_POST['payment_method'] ?? 'Transfer Bank';
    $form['recipient_name'] = trim($_POST['recipient_name'] ?? '');
    $form['phone']          = trim($_POST['phone'] ?? '');
    $form['address']        = trim($_POST['address'] ?? '');
    $phoneDigits = preg_replace('/\D/', '', $form['phone']);
    $needsProof = in_array($payment, $proofMethods, true);

    // cek stok sekali lagi sebelum commit transaksi
    $outOfStock = [];
    foreach ($items as $it) {
        if ($it['quantity'] > $it['stock']) {
            $outOfStock[] = $it['title'];
        }
    }

    $proofError = $needsProof ? check_payment_proof($_FILES['payment_proof'] ?? null) : null;

    if ($form['recipient_name'] === '' || $form['phone'] === '' || $form['address'] === '') {
        $error = 'Nama penerima, nomor telepon, dan alamat wajib diisi.';
    } elseif (mb_strlen($form['recipient_name']) > 100) {
        $error = 'Nama penerima maksimal 100 karakter.';
    } elseif (!preg_match('/^\+?[0-9\s\-]+$/', $form['phone']) || strlen($phoneDigits) < 9 || strlen($phoneDigits) > 15) {
        $error = 'Nomor telepon tidak valid. Gunakan 9-15 angka, contoh: 0812 3456 7890.';
    } elseif (mb_strlen($form['address']) < 10) {
        $error = 'Alamat terlalu singkat. Tulis jalan, nomor, kecamatan, kota, dan kode pos.';
    } elseif (mb_strlen($form['address']) > 500) {
        $error = 'Alamat maksimal 500 karakter.';
    } elseif (!in_array($payment, $payMethods, true)) {
        $error = 'Metode pembayaran tidak valid.';
    } elseif (!empty($outOfStock)) {
        $error = 'Stok tidak cukup untuk: ' . implode(', ', $outOfStock);
    } elseif ($proofError !== null) {
        $error = $proofError;
    } else {
        // simpan file bukti pembayaran (kalau perlu) dengan nama acak
        $proofName = null;
        if ($needsProof) {
            $tmp = $_FILES['payment_proof']['tmp_name'];
            $type = getimagesize($tmp)[2];
            $ext = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'][$type];
            if (!is_dir(PROOF_DIR)) {
                @mkdir(PROOF_DIR, 0775, true);
            }
            $proofName = 'proof_' . date('Ymd') . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
            if (!move_uploaded_file($tmp, PROOF_DIR . $proofName)) {
                $error = 'Gagal menyimpan bukti pembayaran. Pastikan folder assets/images/proofs bisa ditulis.';
                $proofName = null;
            }
        }

        if ($error === null) {
            try {
                $pdo->beginTransaction();

                $receiptNo = 'INV-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));

                // status awal 'pending': menunggu admin mengonfirmasi pembayaran
                $stmt = $pdo->prepare("INSERT INTO orders (receipt_no, user_id, total, payment_method, recipient_name, phone, address, payment_proof, status) VALUES (?,?,?,?,?,?,?,?,'pending')");
                $stmt->execute([$receiptNo, $userId, $grandTotal, $payment, $form['recipient_name'], $form['phone'], $form['address'], $proofName]);
                $orderId = $pdo->lastInsertId();

                foreach ($items as $it) {
                    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, book_id, title, price, quantity, subtotal) VALUES (?,?,?,?,?,?)");
                    $stmt->execute([$orderId, $it['id'], $it['title'], $it['price'], $it['quantity'], $it['price'] * $it['quantity']]);

                    $pdo->prepare("UPDATE books SET stock = stock - ? WHERE id = ?")->execute([$it['quantity'], $it['id']]);
                }

                $pdo->prepare("DELETE FROM cart WHERE user_id = ?")->execute([$userId]);

                $pdo->commit();

                flash('success', 'Pesanan dibuat. Menunggu konfirmasi dari admin.');
                header('Location: ' . BASE_URL . '/receipt.php?order_id=' . $orderId);
                exit;
            } catch (Exception $e) {
                $pdo->rollBack();
                if ($proofName) {
                    @unlink(PROOF_DIR . $proofName);
                }
                $error = 'Transaksi gagal, silakan coba lagi.';
            }
        }
    }
}

$qrisExists = file_exists(__DIR__ . '/' . QRIS_FILE);

$page_title = 'Checkout';
require_once 'includes/header.php';
?>

<div class="page-head">
  <ol class="steps" aria-label="Langkah belanja"><li class="done">Keranjang</li><li class="on">Checkout</li><li>Struk</li></ol>
  <h1 style="margin-top:14px;">Checkout</h1>
</div>

<?php if ($error): ?>
  <div class="alert alert-error" role="alert"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="cart-layout">
  <div class="stack">
    <div class="panel">
      <h2>Alamat pengiriman</h2>
      <div class="form-group">
        <label for="recipient_name">Nama penerima</label>
        <input id="recipient_name" type="text" name="recipient_name" required maxlength="100" autocomplete="name" value="<?= htmlspecialchars($form['recipient_name']) ?>">
      </div>
      <div class="form-group">
        <label for="phone">Nomor telepon</label>
        <input id="phone" type="tel" name="phone" required maxlength="20" inputmode="tel" autocomplete="tel" placeholder="0812 3456 7890" value="<?= htmlspecialchars($form['phone']) ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label for="address">Alamat lengkap</label>
        <textarea id="address" name="address" rows="4" required maxlength="500" autocomplete="street-address" placeholder="Jalan, nomor rumah, RT/RW, kelurahan, kecamatan, kota, kode pos" style="resize:vertical;"><?= htmlspecialchars($form['address']) ?></textarea>
      </div>
    </div>

    <div class="panel">
      <h2>Metode pembayaran</h2>
      <label class="choice"><input type="radio" name="payment_method" value="Transfer Bank" <?= $payment === 'Transfer Bank' ? 'checked' : '' ?>>Transfer Bank</label>
      <label class="choice"><input type="radio" name="payment_method" value="QRIS" <?= $payment === 'QRIS' ? 'checked' : '' ?>>QRIS</label>
      <label class="choice"><input type="radio" name="payment_method" value="Bayar di Tempat (COD)" <?= $payment === 'Bayar di Tempat (COD)' ? 'checked' : '' ?>>Bayar di Tempat (COD)</label>

      <!-- Transfer Bank: nomor rekening -->
      <div class="pay-box" data-pay-for="Transfer Bank" <?= $payment === 'Transfer Bank' ? '' : 'hidden' ?>>
        <p>Transfer tepat sebesar <strong><?= rupiah($grandTotal) ?></strong> ke rekening berikut, lalu unggah bukti transfernya.</p>
        <dl class="bank">
          <div><dt>Bank</dt><dd><?= htmlspecialchars(BANK_NAME) ?></dd></div>
          <div><dt>No. rekening</dt><dd><?= htmlspecialchars(BANK_ACCOUNT_NO) ?> <button type="button" class="copy-btn" data-copy="<?= htmlspecialchars(BANK_ACCOUNT_NO) ?>">Salin</button></dd></div>
          <div><dt>Atas nama</dt><dd><?= htmlspecialchars(BANK_ACCOUNT_NAME) ?></dd></div>
        </dl>
      </div>

      <!-- QRIS: kartu QR -->
      <div class="pay-box" data-pay-for="QRIS" <?= $payment === 'QRIS' ? '' : 'hidden' ?>>
        <p>Scan kode QRIS di bawah untuk membayar <strong><?= rupiah($grandTotal) ?></strong>, lalu unggah bukti pembayarannya.</p>
        <div class="qris-card">
          <?php if ($qrisExists): ?>
            <img src="<?= BASE_URL ?>/<?= QRIS_FILE ?>" alt="Kode QRIS <?= htmlspecialchars(SITE_NAME) ?>">
          <?php else: ?>
            <div class="qris-placeholder"><strong>QRIS</strong><span>Tempat kode QR.<br>Simpan gambarnya di<br><code><?= QRIS_FILE ?></code></span></div>
          <?php endif; ?>
          <p class="qris-name"><?= htmlspecialchars(SITE_NAME) ?></p>
        </div>
      </div>

      <!-- Upload bukti pembayaran (Transfer Bank & QRIS) -->
      <div class="pay-box" data-pay-for="Transfer Bank|QRIS" <?= in_array($payment, $proofMethods, true) ? '' : 'hidden' ?>>
        <div class="form-group" style="margin:0;">
          <label for="payment_proof">Bukti pembayaran</label>
          <input id="payment_proof" type="file" name="payment_proof" accept="image/jpeg,image/png,image/webp">
          <small class="muted">JPG, PNG, atau WEBP, maksimal 2 MB. Pesananmu diproses setelah admin mengonfirmasi pembayaran.</small>
        </div>
      </div>
    </div>

    <div class="panel">
      <h2>Item pesanan</h2>
      <ul class="mini-items">
        <?php foreach ($items as $it): ?>
          <li><span><?= htmlspecialchars($it['title']) ?> &times; <?= $it['quantity'] ?></span><span><?= rupiah($it['price'] * $it['quantity']) ?></span></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>

  <aside class="panel summary">
    <h2>Total pembayaran</h2>
    <div class="row"><span>Subtotal</span><span><?= rupiah($subtotal) ?></span></div>
    <div class="row"><span>Ongkos kirim</span><span><?= rupiah($shipping) ?></span></div>
    <div class="row total"><span>Total</span><span><?= rupiah($grandTotal) ?></span></div>
    <button type="submit" class="btn btn-primary btn-block">Buat pesanan</button>
  </aside>
</form>

<?php require_once 'includes/footer.php'; ?>
