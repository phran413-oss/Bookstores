(function () {
  var body = document.body;
  var base = body.dataset.base || '';
  var logged = body.dataset.logged === '1';

  // Bookmark / wishlist
  function toggleWish(btn) {
    btn.disabled = true;
    fetch(base + '/wishlist.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=toggle&book_id=' + encodeURIComponent(btn.dataset.wish)
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        btn.classList.toggle('active', d.wished);
        btn.setAttribute('aria-pressed', d.wished ? 'true' : 'false');
        var label = btn.querySelector('.wish-label');
        if (label) label.textContent = d.wished ? 'Tersimpan di wishlist' : 'Simpan ke wishlist';
        if (!d.wished && document.querySelector('[data-wishlist-page]')) location.reload();
      })
      .catch(function () {})
      .then(function () { btn.disabled = false; });
  }

  document.addEventListener('click', function (e) {
    var w = e.target.closest('[data-wish]');
    if (w) {
      e.preventDefault();
      if (!logged) { location.href = base + '/login.php'; return; }
      toggleWish(w);
      return;
    }
    // Tombol − / + jumlah di keranjang
    var s = e.target.closest('[data-step]');
    if (s) {
      var form = s.closest('form');
      var input = form.querySelector('input[name=quantity]');
      var min = parseInt(input.min, 10) || 1;
      var max = parseInt(input.max, 10) || 999;
      var next = Math.min(max, Math.max(min, (parseInt(input.value, 10) || min) + parseInt(s.dataset.step, 10)));
      if (next !== parseInt(input.value, 10)) { input.value = next; form.submit(); }
    }
  });

  document.addEventListener('change', function (e) {
    if (e.target.matches('.qty input')) e.target.form.submit();
  });

  // Metode pembayaran: tampilkan rekening / QRIS / kolom unggah bukti
  function syncPay() {
    var cur = document.querySelector('input[name=payment_method]:checked');
    var val = cur ? cur.value : '';
    document.querySelectorAll('[data-pay-for]').forEach(function (el) {
      var show = el.dataset.payFor.split('|').indexOf(val) !== -1;
      el.hidden = !show;
      el.querySelectorAll('input[type=file]').forEach(function (i) { i.required = show; });
    });
  }
  document.querySelectorAll('input[name=payment_method]').forEach(function (r) {
    r.addEventListener('change', syncPay);
  });
  syncPay();

  // Tombol "Salin" nomor rekening
  document.addEventListener('click', function (e) {
    var c = e.target.closest('[data-copy]');
    if (!c || !navigator.clipboard) return;
    navigator.clipboard.writeText(c.dataset.copy).then(function () {
      var old = c.textContent;
      c.textContent = 'Tersalin';
      setTimeout(function () { c.textContent = old; }, 1500);
    });
  });

  // Pesan sukses hilang sendiri
  document.querySelectorAll('[data-autohide]').forEach(function (el) {
    setTimeout(function () { el.remove(); }, 3500);
  });
})();
