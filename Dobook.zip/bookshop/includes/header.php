<?php
// pastikan config sudah di-load oleh halaman pemanggil sebelum include ini
$current = basename($_SERVER['PHP_SELF']);
$cc = is_logged_in() ? cart_count($pdo) : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - ' . SITE_NAME : SITE_NAME ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Courier+Prime:wght@400;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Young+Serif&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body data-base="<?= BASE_URL ?>" data-logged="<?= is_logged_in() ? '1' : '0' ?>">
<?php require_once __DIR__ . '/icons.php'; ?>

<header class="site-header">
  <div class="bar">
    <a href="<?= BASE_URL ?>/index.php" class="logo" aria-label="<?= SITE_NAME ?> - beranda"><span class="logo-mark"></span><?= SITE_NAME ?></a>

    <nav class="nav" aria-label="Menu utama">
      <a href="<?= BASE_URL ?>/index.php" class="<?= $current === 'index.php' ? 'active' : '' ?>">Home</a>
      <a href="<?= BASE_URL ?>/category.php" class="<?= in_array($current, ['category.php','book_detail.php']) ? 'active' : '' ?>">Books</a>
      <a href="<?= BASE_URL ?>/wishlist.php" class="<?= $current === 'wishlist.php' ? 'active' : '' ?>">Wishlist</a>
      <a href="#" class="<?= $current === 'forum.php' ? 'active' : '' ?>">Forum</a>
    </nav>

    <form class="search" action="<?= BASE_URL ?>/category.php" method="get" role="search">
      <input type="search" name="q" placeholder="Cari judul atau penulis" aria-label="Cari buku" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
      <button type="submit" aria-label="Cari"><?= icon('search') ?></button>
    </form>

    <div class="actions">
      <?php if (is_logged_in()): ?>
        <a class="act" href="<?= BASE_URL ?>/cart.php" aria-label="Keranjang"><?= icon('bag') ?><span class="act-label">Keranjang</span><?php if ($cc > 0): ?><span class="badge"><?= $cc ?></span><?php endif; ?></a>
        <a class="act" href="<?= BASE_URL ?>/orders.php" aria-label="Pesanan saya"><?= icon('receipt') ?><span class="act-label">Pesanan</span></a>
        <a class="act act-user" href="<?= BASE_URL ?>/logout.php" aria-label="Keluar"><?= icon('logout') ?><span class="act-label"><?= htmlspecialchars($_SESSION['name']) ?> &middot; Keluar</span></a>
      <?php else: ?>
        <a class="act" href="<?= BASE_URL ?>/cart.php" aria-label="Keranjang"><?= icon('bag') ?></a>
        <a class="act act-primary" href="<?= BASE_URL ?>/login.php"><?= icon('user') ?>Log in</a>
      <?php endif; ?>
    </div>
  </div>
</header>

<?php if ($m = flash('success')): ?>
  <div class="toast" role="status" data-autohide><?= htmlspecialchars($m) ?></div>
<?php endif; ?>

<main class="container">
<?php if ($m = flash('error')): ?>
  <div class="alert alert-error" role="alert"><?= htmlspecialchars($m) ?></div>
<?php endif; ?>
