<?php
require_once 'config.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT b.*, c.name AS category_name FROM books b LEFT JOIN categories c ON b.category_id = c.id WHERE b.id = ?");
$stmt->execute([$id]);
$book = $stmt->fetch();

if (!$book) {
    header('Location: ' . BASE_URL . '/category.php');
    exit;
}

$wishIds = wish_ids($pdo);
$isWished = in_array($id, $wishIds);

$stmt3 = $pdo->prepare("SELECT * FROM books WHERE id <> ? ORDER BY RAND() LIMIT 6");
$stmt3->execute([$id]);
$others = $stmt3->fetchAll();

$page_title = $book['title'];
require_once 'includes/header.php';
?>

<div class="page-head" style="padding-bottom:8px;">
  <div class="crumbs"><a href="<?= BASE_URL ?>/index.php">Home</a> / <a href="<?= BASE_URL ?>/category.php">Books</a> / <?= htmlspecialchars($book['title']) ?></div>
</div>

<section class="detail">
  <div class="cover"><img src="<?= book_image_url($book['image']) ?>" alt="Sampul <?= htmlspecialchars($book['title']) ?>"></div>

  <div>
    <h1><?= htmlspecialchars($book['title']) ?></h1>
    <p class="by"><?= htmlspecialchars($book['author']) ?></p>
    <?php if ($book['category_name']): ?><span class="chip"><?= htmlspecialchars($book['category_name']) ?></span><?php endif; ?>

    <div class="detail-price">
      <strong><?= rupiah($book['price']) ?></strong>
    </div>

    <?php if (trim((string)$book['description']) !== ''): ?>
      <p class="desc"><?= nl2br(htmlspecialchars($book['description'])) ?></p>
    <?php endif; ?>

    <span class="stock <?= $book['stock'] > 0 ? '' : 'out' ?>"><?= $book['stock'] > 0 ? 'Stok tersedia: ' . (int)$book['stock'] : 'Stok habis' ?></span>

    <div class="detail-actions">
      <form method="post" action="<?= BASE_URL ?>/cart.php">
        <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
        <input type="hidden" name="action" value="add">
        <button type="submit" class="btn btn-primary" <?= $book['stock'] <= 0 ? 'disabled' : '' ?>><?= icon('bag') ?>Tambah ke keranjang</button>
      </form>
      <button type="button" class="btn btn-outline btn-wish <?= $isWished ? 'active' : '' ?>" data-wish="<?= $book['id'] ?>" aria-pressed="<?= $isWished ? 'true' : 'false' ?>">
        <?= icon('bookmark') ?><span class="wish-label"><?= $isWished ? 'Tersimpan di wishlist' : 'Simpan ke wishlist' ?></span>
      </button>
    </div>
  </div>
</section>

<?php if (!empty($others)): ?>
<section>
  <div class="sec-head"><h2>Buku lainnya</h2><a href="<?= BASE_URL ?>/category.php">Semua buku</a></div>
  <div class="scroller">
    <?php foreach ($others as $b) render_book_card($b, $wishIds); ?>
  </div>
</section>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
