<?php
require_once 'config.php';

if (is_logged_in()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Email dan password wajib diisi.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        // hanya akun role user yang boleh masuk di web toko (admin login di web admin)
        if ($user && $user['role'] === 'user' && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            header('Location: ' . BASE_URL . '/index.php');
            exit;
        } else {
            $error = 'Email atau password salah.';
        }
    }
}

$covers = random_covers($pdo);
$page_title = 'Login';
require_once 'includes/header.php';
?>

<div class="auth">
  <div class="auth-side">
    <div>
      <h2>Selamat datang kembali.</h2>
      <p>Masuk untuk melihat wishlist, keranjang, dan riwayat pesananmu.</p>
    </div>
    <div class="fan">
      <?php foreach ($covers as $c): ?><img src="<?= book_image_url($c['image']) ?>" alt=""><?php endforeach; ?>
    </div>
  </div>
  <div class="auth-form">
    <h1>Log in</h1>
    <?php if ($error): ?>
      <div class="alert alert-error" role="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post">
      <div class="form-group">
        <label for="email">Email</label>
        <input id="email" type="email" name="email" required autocomplete="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input id="password" type="password" name="password" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn btn-primary btn-block">Log in</button>
    </form>
    <p class="auth-alt">Belum punya akun? <a href="<?= BASE_URL ?>/register.php">Daftar di sini</a></p>
    <div class="note">Demo: user@bookshop.com / user123<br>Jalankan <a href="<?= BASE_URL ?>/setup.php" style="text-decoration:underline;">setup.php</a> sekali dulu untuk membuat akun demo ini.</div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
