<?php
require_once 'config.php';

if (is_logged_in()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if ($name === '' || $email === '' || $password === '') {
        $error = 'Semua kolom wajib diisi.';
    } elseif ($password !== $confirm) {
        $error = 'Konfirmasi password tidak cocok.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email sudah terdaftar.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?,?,?,'user')");
            $stmt->execute([$name, $email, $hash]);

            session_regenerate_id(true);
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['name'] = $name;
            $_SESSION['role'] = 'user';

            flash('success', 'Registrasi berhasil! Selamat datang, ' . $name . '.');
            header('Location: ' . BASE_URL . '/index.php');
            exit;
        }
    }
}

$covers = random_covers($pdo);
$page_title = 'Daftar';
require_once 'includes/header.php';
?>

<div class="auth">
  <div class="auth-side">
    <div>
      <h2>Simpan, pesan, lalu baca.</h2>
      <p>Buat akun untuk menyimpan buku incaran dan membeli dengan lebih cepat.</p>
    </div>
    <div class="fan">
      <?php foreach ($covers as $c): ?><img src="<?= book_image_url($c['image']) ?>" alt=""><?php endforeach; ?>
    </div>
  </div>
  <div class="auth-form">
    <h1>Buat akun</h1>
    <?php if ($error): ?>
      <div class="alert alert-error" role="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post">
      <div class="form-group">
        <label for="name">Nama lengkap</label>
        <input id="name" type="text" name="name" required autocomplete="name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input id="email" type="email" name="email" required autocomplete="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="password">Password (min. 6 karakter)</label>
        <input id="password" type="password" name="password" required autocomplete="new-password">
      </div>
      <div class="form-group">
        <label for="confirm">Konfirmasi password</label>
        <input id="confirm" type="password" name="confirm" required autocomplete="new-password">
      </div>
      <button type="submit" class="btn btn-primary btn-block">Daftar</button>
    </form>
    <p class="auth-alt">Sudah punya akun? <a href="<?= BASE_URL ?>/login.php">Log in</a></p>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
