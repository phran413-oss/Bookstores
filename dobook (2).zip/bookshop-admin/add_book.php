<?php
// Memuat koneksi database ($pdo), konstanta (BASE_URL, UPLOAD_DIR), dan fungsi bantu
require_once 'config.php';
// Hanya admin yang boleh membuka halaman ini; selain itu diarahkan ke login
require_admin();

// Ambil semua genre (tabel categories) untuk pilihan dropdown, urut abjad
$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
// Penampung pesan error; null artinya belum ada error
$error = null;

// Blok ini hanya jalan ketika form disubmit (method POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Judul buku, spasi di awal/akhir dibuang
    $title = trim($_POST['title'] ?? '');
    // Nama penulis, spasi di awal/akhir dibuang
    $author = trim($_POST['author'] ?? '');
    // ID genre jadi angka; kalau 0 (tidak dipilih) diubah jadi null agar tersimpan kosong di DB
    $category_id = (int)($_POST['category_id'] ?? 0) ?: null;
    // Harga diubah ke angka desimal
    $price = (float)($_POST['price'] ?? 0);
    // Stok diubah ke angka bulat
    $stock = (int)($_POST['stock'] ?? 0);
    // Deskripsi buku, spasi di awal/akhir dibuang
    $description = trim($_POST['description'] ?? '');

    // Validasi: judul & penulis tidak boleh kosong dan harga harus lebih dari 0
    if ($title === '' || $author === '' || $price <= 0) {
        // Pesan error yang ditampilkan di atas form
        $error = 'Judul, penulis, dan harga wajib diisi dengan benar.';
    } else {
        // Nama file cover bawaan kalau admin tidak mengunggah gambar
        $imageName = 'no-image.png';

        // Cek apakah admin memilih file cover
        if (!empty($_FILES['image']['name'])) {
            // Ambil ekstensi file (huruf kecil) untuk dicek formatnya
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            // Daftar ekstensi gambar yang diizinkan
            $allowed = ['jpg','jpeg','png','webp'];
            // Lolos jika ekstensi diizinkan DAN upload tidak error
            if (in_array($ext, $allowed) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                // Buat nama file unik (waktu + angka acak) supaya tidak menimpa file lain
                $imageName = 'book_' . time() . '_' . rand(1000,9999) . '.' . $ext;
                // Pindahkan file dari folder sementara ke folder upload cover
                move_uploaded_file($_FILES['image']['tmp_name'], UPLOAD_DIR . $imageName);
            } else {
                // Format tidak valid atau upload gagal
                $error = 'Format gambar harus jpg, jpeg, png, atau webp.';
            }
        }

        // Simpan ke database hanya jika tidak ada error
        if (!$error) {
            // Query INSERT memakai placeholder (?) agar aman dari SQL injection.
            // created_at terisi otomatis, sehingga buku baru langsung masuk section "What's new"
            $stmt = $pdo->prepare("INSERT INTO books (title, author, category_id, price, stock, description, image) VALUES (?,?,?,?,?,?,?)");
            // Jalankan query dengan nilai sesuai urutan placeholder
            $stmt->execute([$title, $author, $category_id, $price, $stock, $description, $imageName]);
            // Simpan pesan sukses untuk ditampilkan setelah redirect
            flash('success', 'Buku "' . $title . '" berhasil ditambahkan.');
            // Kembali ke daftar buku
            header('Location: ' . BASE_URL . '/books.php');
            // Hentikan script setelah redirect
            exit;
        }
    }
}

// Judul tab browser untuk halaman ini
$page_title = 'Tambah Buku';
// Memuat header + sidebar admin
require_once 'includes/header.php';
?>

<?php // Judul halaman ?>
<h1>Tambah Buku</h1>
<?php // Keterangan singkat: buku baru otomatis masuk What's new, genre diatur di menu Kelola Genre ?>
<p class="muted" style="margin-top:-6px;">Buku baru otomatis tampil di section <strong>What's new</strong> di beranda. Genre bisa ditambah atau diubah langsung lewat tombol <strong>Kelola genre</strong> di bawah pilihan genre.</p>

<?php // Tampilkan kotak error jika ada ?>
<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php // Form tambah buku; enctype multipart wajib agar file cover bisa diunggah ?>
<form method="post" enctype="multipart/form-data" style="background:#fff;padding:24px;border-radius:10px;border:1px solid #e4e4e4;max-width:600px;">
  <?php // Input judul; value diisi ulang dari POST agar tidak hilang saat terjadi error ?>
  <div class="form-group">
    <label>Judul Buku</label>
    <input type="text" name="title" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
  </div>
  <?php // Input penulis ?>
  <div class="form-group">
    <label>Penulis</label>
    <input type="text" name="author" required value="<?= htmlspecialchars($_POST['author'] ?? '') ?>">
  </div>
  <?php // Dropdown genre ?>
  <div class="form-group">
    <label>Genre</label>
    <select name="category_id">
      <?php // Pilihan kosong = buku tanpa genre ?>
      <option value="">-- Pilih Genre --</option>
      <?php // Tampilkan setiap genre sebagai pilihan ?>
      <?php foreach ($categories as $c): ?>
        <?php // Genre yang tadi dipilih tetap terpilih jika form dikirim ulang karena error ?>
        <option value="<?= $c['id'] ?>" <?= (int)($_POST['category_id'] ?? 0) === (int)$c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <?php // Panel kelola genre langsung di sini (tambah / edit / hapus tanpa pindah halaman) ?>
    <?php require 'includes/genre_manager.php'; ?>
  </div>
  <?php // Harga dan stok dibuat sebaris (flex) ?>
  <div style="display:flex;gap:12px;">
    <?php // Kolom harga ?>
    <div class="form-group" style="flex:1;">
      <label>Harga (Rp)</label>
      <input type="number" name="price" min="0" step="1" required value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
    </div>
    <?php // Kolom stok ?>
    <div class="form-group" style="flex:1;">
      <label>Stok</label>
      <input type="number" name="stock" min="0" required value="<?= htmlspecialchars($_POST['stock'] ?? '') ?>">
    </div>
  </div>
  <?php // Deskripsi buku ?>
  <div class="form-group">
    <label>Deskripsi</label>
    <textarea name="description" rows="4"><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
  </div>
  <?php // Upload cover; hanya menerima jpg, jpeg, png, webp ?>
  <div class="form-group">
    <label>Cover Buku</label>
    <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
  </div>
  <?php // Tombol simpan dan batal (kembali ke daftar buku) ?>
  <button type="submit" class="btn btn-primary">Simpan Buku</button>
  <a href="<?= BASE_URL ?>/books.php" class="btn btn-outline">Batal</a>
</form>

<?php // Memuat footer halaman ?>
<?php require_once 'includes/footer.php'; ?>
