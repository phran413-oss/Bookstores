<?php
// ============================================
// KONFIGURASI WEB ADMIN (terpisah dari web toko/user)
// ============================================
define('BASE_URL', '/bookshop-admin');                 // URL web admin (ganti jika nama folder berbeda)
define('STORE_URL', '/bookshop');                      // URL web toko/user
define('STORE_DIR', dirname(__DIR__) . '/bookshop');   // folder web toko di htdocs (tempat cover buku disimpan)
define('SITE_NAME', 'Dobook');                         // samakan dengan SITE_NAME di web toko

// Web admin punya sesi sendiri, terpisah dari web toko.
session_name('BOOKSHOP_ADMIN');
session_set_cookie_params([
    'path'     => BASE_URL,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

// Database yang sama dengan web toko
$DB_HOST = 'localhost';
$DB_NAME = 'bookshop';
$DB_USER = 'root';
$DB_PASS = ''; // default XAMPP kosong

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Koneksi database gagal. Pastikan XAMPP (Apache & MySQL) aktif dan database 'bookshop' sudah di-import. Detail: " . $e->getMessage());
}

// Sesi basi: kalau akun di sesi sudah tidak ada di database (mis. database di-import ulang),
// anggap belum login supaya tidak terjadi error foreign key di keranjang / like / wishlist.
if (isset($_SESSION['user_id'])) {
    $chk = $pdo->prepare("SELECT id FROM users WHERE id = ?");
    $chk->execute([$_SESSION['user_id']]);
    if (!$chk->fetch()) {
        unset($_SESSION['user_id'], $_SESSION['name'], $_SESSION['role'], $_SESSION['email']);
    }
}

// Cover buku disimpan di folder web toko supaya langsung tampil di sana
define('UPLOAD_DIR', STORE_DIR . '/assets/images/uploads/');
define('UPLOAD_URL', STORE_URL . '/assets/images/uploads/');
define('PROOF_URL', STORE_URL . '/assets/images/proofs/');   // bukti pembayaran (disimpan oleh web toko)

// ============================================
// HELPER FUNCTIONS
// ============================================

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return is_logged_in() && $_SESSION['role'] === 'admin';
}

function require_admin() {
    if (!is_admin()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function rupiah($num) {
    return 'Rp' . number_format($num, 0, ',', '.');
}

function book_image_url($image) {
    if (empty($image) || $image === 'no-image.png') {
        return STORE_URL . '/assets/images/no-image.png';
    }
    return UPLOAD_URL . $image;
}

function flash($key, $msg = null) {
    if ($msg !== null) {
        $_SESSION['flash'][$key] = $msg;
        return;
    }
    if (isset($_SESSION['flash'][$key])) {
        $val = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $val;
    }
    return null;
}

// ============================================
// HELPER TAMPILAN (UI)
// ============================================

function icon($name, $extra = '') {
    return '<svg class="ic ' . $extra . '" aria-hidden="true"><use href="#i-' . $name . '"/></svg>';
}

function status_label($status) {
    $map = [
        'pending'   => 'Menunggu konfirmasi',
        'paid'      => 'Lunas',
        'shipped'   => 'Dikirim',
        'completed' => 'Selesai',
        'cancelled' => 'Dibatalkan',
    ];
    return $map[$status] ?? ucfirst($status);
}

function random_covers($pdo, $n = 3) {
    $n = (int)$n;
    return $pdo->query("SELECT image FROM books WHERE image <> 'no-image.png' AND image <> '' ORDER BY RAND() LIMIT $n")->fetchAll();
}
