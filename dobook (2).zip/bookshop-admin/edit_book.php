<?php
// Memuat koneksi database ($pdo), konstanta, dan fungsi bantu
require_once 'config.php';
// Hanya admin yang boleh membuka halaman ini
require_admin();

// ID buku yang diedit, diambil dari URL (?id=...) dan dipaksa jadi angka
$id = (int)($_GET['id'] ?? 0);
// Siapkan query untuk mengambil data buku
$stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
// Jalankan query dengan ID tersebut
$stmt->execute([$id]);
// Ambil satu baris data buku (false jika tidak ditemukan)
$book = $stmt->fetch();

// Jika buku tidak ada (ID salah / sudah dihapus)
if (!$book) {
    // Kembali ke daftar buku
    header('Location: ' . BASE_URL . '/books.php');
    // Hentikan script
    exit;
}

// Ambil semua genre untuk pilihan dropdown, urut abjad
$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
// Penampung pesan error; null artinya belum ada error
$error = null;

// Blok ini hanya jalan ketika form disubmit (method POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Judul baru, spasi di awal/akhir dibuang
    $title = trim($_POST['title'] ?? '');
    // Penulis baru, spasi di awal/akhir dibuang
    $author = trim($_POST['author'] ?? '');
    // ID genre jadi angka; kalau 0 (tidak dipilih) diubah jadi null
    $category_id = (int)($_POST['category_id'] ?? 0) ?: null;
    // Harga diubah ke angka desimal
    $price = (float)($_POST['price'] ?? 0);
    // Stok diubah ke angka bulat
    $stock = (int)($_POST['stock'] ?? 0);
    // Deskripsi baru, spasi di awal/akhir dibuang
    $description = trim($_POST['description'] ?? '');

    // Validasi: judul & penulis tidak boleh kosong dan harga harus lebih dari 0
    if ($title === '' || $author === '' || $price <= 0) {
        // Pesan error yang ditampilkan di atas form
        $error = 'Judul, penulis, dan harga wajib diisi dengan benar.';
    } else {
        // Awalnya pakai cover lama; hanya berubah jika admin mengunggah cover baru
        $imageName = $book['image'];

        // Cek apakah admin memilih file cover baru
        if (!empty($_FILES['image']['name'])) {
            // Ambil ekstensi file (huruf kecil) untuk dicek formatnya
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            // Daftar ekstensi gambar yang diizinkan
            $allowed = ['jpg','jpeg','png','webp'];
            // Lolos jika ekstensi diizinkan DAN upload tidak error
            if (in_array($ext, $allowed) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                // Buat nama file unik (waktu + angka acak) agar tidak menimpa file lain
                $newImage = 'book_' . time() . '_' . rand(1000,9999) . '.' . $ext;
                // Pindahkan file dari folder sementara ke folder upload cover
                move_uploaded_file($_FILES['image']['tmp_name'], UPLOAD_DIR . $newImage);

                // Hapus cover lama dari folder agar tidak menumpuk (kecuali gambar bawaan)
                if ($imageName !== 'no-image.png' && file_exists(UPLOAD_DIR . $imageName)) {
                    // Tanda @ menyembunyikan warning kalau file gagal dihapus
                    @unlink(UPLOAD_DIR . $imageName);
                }
                // Pakai nama file cover yang baru
                $imageName = $newImage;
            } else {
                // Format tidak valid atau upload gagal
                $error = 'Format gambar harus jpg, jpeg, png, atau webp.';
            }
        }

        // Simpan perubahan hanya jika tidak ada error
        if (!$error) {
            // Query UPDATE memakai placeholder (?) agar aman dari SQL injection
            $stmt = $pdo->prepare("UPDATE books SET title=?, author=?, category_id=?, price=?, stock=?, description=?, image=? WHERE id=?");
            // Jalankan query; $id terakhir untuk kondisi WHERE
            $stmt->execute([$title, $author, $category_id, $price, $stock, $description, $imageName, $id]);
            // Simpan pesan sukses untuk ditampilkan setelah redirect
            flash('success', 'Buku berhasil diperbarui.');
            // Kembali ke daftar buku
            header('Location: ' . BASE_URL . '/books.php');
            // Hentikan script setelah redirect
            exit;
        }
    }
}

// Judul tab browser
$page_title = 'Edit Buku';
// Memuat header + sidebar admin
require_once 'includes/header.php';
?>

<?php // Judul halaman ?>
<h1>Edit Buku</h1>

<?php // Tampilkan kotak error jika ada ?>
<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php // Form edit; enctype multipart wajib agar cover baru bisa diunggah ?>
<form method="post" enctype="multipart/form-data" style="background:#fff;padding:24px;border-radius:10px;border:1px solid #e4e4e4;max-width:600px;">
  <?php // Judul: pakai input terakhir (jika error) atau data buku dari database ?>
  <div class="form-group">
    <label>Judul Buku</label>
    <input type="text" name="title" required value="<?= htmlspecialchars($_POST['title'] ?? $book['title']) ?>">
  </div>
  <?php // Penulis ?>
  <div class="form-group">
    <label>Penulis</label>
    <input type="text" name="author" required value="<?= htmlspecialchars($_POST['author'] ?? $book['author']) ?>">
  </div>
  <?php // Dropdown genre ?>
  <div class="form-group">
    <label>Genre</label>
    <select name="category_id">
      <?php // Pilihan kosong = buku tanpa genre ?>
      <option value="">-- Pilih Genre --</option>
      <?php // Tampilkan setiap genre sebagai pilihan ?>
      <?php foreach ($categories as $c): ?>
        <?php // Genre milik buku ini otomatis terpilih ?>
        <option value="<?= $c['id'] ?>" <?= $c['id'] == $book['category_id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <?php // Panel kelola genre langsung di sini (tambah / edit / hapus tanpa pindah halaman) ?>
    <?php require 'includes/genre_manager.php'; ?>
  </div>
  <?php // Harga dan stok dibuat sebaris (flex) ?>
  <div style="display:flex;gap:12px;">
    <?php // Kolom harga ?>
    <div class="form-group" style="flex:1;">
      <label>Harga (Rp)</label>
      <input type="number" name="price" min="0" step="1" required value="<?= htmlspecialchars($_POST['price'] ?? $book['price']) ?>">
    </div>
    <?php // Kolom stok ?>
    <div class="form-group" style="flex:1;">
      <label>Stok</label>
      <input type="number" name="stock" min="0" required value="<?= htmlspecialchars($_POST['stock'] ?? $book['stock']) ?>">
    </div>
  </div>
  <?php // Deskripsi buku ?>
  <div class="form-group">
    <label>Deskripsi</label>
    <textarea name="description" rows="4"><?= htmlspecialchars($_POST['description'] ?? $book['description']) ?></textarea>
  </div>
  <?php // Cover: tampilkan cover saat ini, lalu input untuk menggantinya ?>
  <div class="form-group">
    <label>Cover Saat Ini</label><br>
    <?php // Pratinjau cover yang sedang dipakai ?>
    <img src="<?= book_image_url($book['image']) ?>" style="width:80px;border-radius:6px;margin-bottom:8px;">
    <label>Ganti Cover (kosongkan jika tidak ingin mengubah)</label>
    <?php // Upload cover baru (opsional) ?>
    <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
  </div>
  <?php // Tombol simpan dan batal (kembali ke daftar buku) ?>
  <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
  <a href="<?= BASE_URL ?>/books.php" class="btn btn-outline">Batal</a>
</form>

<?php // Memuat footer halaman ?>
<?php require_once 'includes/footer.php'; ?>
