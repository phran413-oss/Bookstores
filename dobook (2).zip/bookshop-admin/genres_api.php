<?php
// Endpoint AJAX untuk kelola genre langsung dari form Tambah/Edit Buku.
// Menerima POST: action = list | add | edit | delete. Selalu membalas JSON.
require_once 'config.php';

// Balasan selalu berupa JSON
header('Content-Type: application/json; charset=utf-8');

// Hanya admin yang boleh; selain itu balas 403 (bukan redirect, karena dipanggil lewat fetch)
if (!is_admin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Akses ditolak. Silakan login sebagai admin.']);
    exit;
}

// Ambil daftar genre + jumlah bukunya, urut abjad
function genre_list($pdo) {
    return $pdo->query("SELECT c.id, c.name, (SELECT COUNT(*) FROM books b WHERE b.category_id = c.id) AS book_count
                        FROM categories c ORDER BY c.name")->fetchAll();
}

// Kirim balasan sukses beserta daftar genre terbaru (supaya dropdown & daftar ikut ter-update)
function respond($pdo, $extra = []) {
    echo json_encode(array_merge(['ok' => true, 'genres' => genre_list($pdo)], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

// Kirim balasan gagal dengan pesan yang bisa ditampilkan ke admin
function fail($msg) {
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

// Jenis aksi, ID genre, dan nama genre dari form
$action = $_POST['action'] ?? 'list';
$id     = (int)($_POST['id'] ?? 0);
$name   = trim($_POST['name'] ?? '');

// Aksi list tidak mengubah data: langsung kirim daftar genre
if ($action === 'list') respond($pdo);

// Selain list harus lewat POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Metode tidak valid.');

if ($action === 'add' || $action === 'edit') {
    // Validasi nama: tidak boleh kosong dan maksimal 100 karakter
    if ($name === '') fail('Nama genre wajib diisi.');
    if (mb_strlen($name) > 100) fail('Nama genre maksimal 100 karakter.');

    // Cegah nama ganda (saat edit, genre itu sendiri dikecualikan)
    $dup = $pdo->prepare("SELECT id FROM categories WHERE name = ? AND id <> ?");
    $dup->execute([$name, $action === 'edit' ? $id : 0]);
    if ($dup->fetch()) fail('Genre "' . $name . '" sudah ada.');

    if ($action === 'add') {
        // Tambah genre baru lalu kirim ID-nya agar langsung terpilih di dropdown
        $pdo->prepare("INSERT INTO categories (name) VALUES (?)")->execute([$name]);
        respond($pdo, ['new_id' => (int)$pdo->lastInsertId()]);
    }

    // Ubah nama genre yang ada
    $pdo->prepare("UPDATE categories SET name = ? WHERE id = ?")->execute([$name, $id]);
    respond($pdo);
}

if ($action === 'delete') {
    // Hapus genre; buku dengan genre ini tidak ikut terhapus (kolom category_id jadi NULL)
    $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
    respond($pdo);
}

// Aksi tidak dikenal
fail('Aksi tidak dikenal.');
