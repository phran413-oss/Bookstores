<?php
require_once 'config.php';
require_admin();

// Genre disimpan di tabel `categories` (dipakai juga untuk filter di halaman Books pada web toko).
$error = null;
$editId = (int)($_GET['edit'] ?? 0);

function genre_name_taken($pdo, $name, $exceptId = 0) {
    $stmt = $pdo->prepare("SELECT id FROM categories WHERE name = ? AND id <> ?");
    $stmt->execute([$name, $exceptId]);
    return (bool)$stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');

    if ($action === 'add' || $action === 'edit') {
        if ($name === '') {
            $error = 'Nama genre wajib diisi.';
        } elseif (mb_strlen($name) > 100) {
            $error = 'Nama genre maksimal 100 karakter.';
        } elseif (genre_name_taken($pdo, $name, $action === 'edit' ? $id : 0)) {
            $error = 'Genre "' . $name . '" sudah ada.';
        } elseif ($action === 'add') {
            $pdo->prepare("INSERT INTO categories (name) VALUES (?)")->execute([$name]);
            flash('success', 'Genre "' . $name . '" berhasil ditambahkan.');
            header('Location: ' . BASE_URL . '/genres.php');
            exit;
        } else {
            $pdo->prepare("UPDATE categories SET name = ? WHERE id = ?")->execute([$name, $id]);
            flash('success', 'Genre berhasil diperbarui.');
            header('Location: ' . BASE_URL . '/genres.php');
            exit;
        }
        if ($action === 'edit') $editId = $id; // tetap di mode edit kalau ada error
    } elseif ($action === 'delete') {
        // buku dengan genre ini tidak ikut terhapus; genre-nya dikosongkan (ON DELETE SET NULL)
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
        flash('success', 'Genre dihapus. Buku di genre ini menjadi tanpa genre.');
        header('Location: ' . BASE_URL . '/genres.php');
        exit;
    }
}

$genres = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM books b WHERE b.category_id = c.id) AS book_count FROM categories c ORDER BY c.name")->fetchAll();

$editing = null;
if ($editId > 0) {
    foreach ($genres as $g) if ((int)$g['id'] === $editId) $editing = $g;
}

$page_title = 'Kelola Genre';
require_once 'includes/header.php';
?>

<div class="admin-topbar">
  <h1 style="margin:0;">Kelola Genre</h1>
</div>

<?php if ($error): ?><div class="alert alert-error" role="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start;">
  <form method="post" class="cart-summary" style="flex:1;min-width:260px;max-width:360px;">
    <h3 style="margin-top:0;"><?= $editing ? 'Edit genre' : 'Tambah genre' ?></h3>
    <input type="hidden" name="action" value="<?= $editing ? 'edit' : 'add' ?>">
    <?php if ($editing): ?><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>"><?php endif; ?>
    <div class="form-group">
      <label for="name">Nama genre</label>
      <input id="name" type="text" name="name" required maxlength="100" placeholder="contoh: Novel, Self Improvement"
             value="<?= htmlspecialchars($_POST['name'] ?? ($editing['name'] ?? '')) ?>" <?= $editing ? 'autofocus' : '' ?>>
    </div>
    <button type="submit" class="btn btn-primary"><?= $editing ? 'Simpan perubahan' : 'Tambah genre' ?></button>
    <?php if ($editing): ?><a href="<?= BASE_URL ?>/genres.php" class="btn btn-outline">Batal</a><?php endif; ?>
  </form>

  <div style="flex:2;min-width:320px;">
    <?php if (empty($genres)): ?>
      <div class="empty">Belum ada genre. Tambahkan genre pertama lewat form di samping.</div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Genre</th><th>Jumlah buku</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($genres as $g): ?>
          <tr>
            <td><?= htmlspecialchars($g['name']) ?></td>
            <td><?= (int)$g['book_count'] ?></td>
            <td style="white-space:nowrap;">
              <a href="<?= BASE_URL ?>/genres.php?edit=<?= $g['id'] ?>" class="btn btn-outline" style="padding:5px 10px;font-size:12px;">Edit</a>
              <form method="post" style="display:inline;" onsubmit="return confirm('Hapus genre ini? <?= (int)$g['book_count'] ?> buku akan menjadi tanpa genre.');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= $g['id'] ?>">
                <button type="submit" class="btn btn-danger" style="padding:5px 10px;font-size:12px;">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
