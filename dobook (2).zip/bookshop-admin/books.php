<?php
// Memuat koneksi database ($pdo), konstanta, dan fungsi bantu
require_once 'config.php';
// Hanya admin yang boleh membuka halaman ini
require_admin();

// Blok hapus buku: jalan jika ada POST dengan action = delete (dari tombol Hapus)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    // ID buku yang akan dihapus, dipaksa jadi angka
    $id = (int)($_POST['id'] ?? 0);
    // Variabel untuk menyimpan nama file cover buku yang dihapus
    $img = null;
    // Ambil nama file cover sebelum bukunya dihapus
    $stmt = $pdo->prepare("SELECT image FROM books WHERE id = ?");
    // Jalankan query dengan ID buku
    $stmt->execute([$id]);
    // Ambil satu baris hasil
    $row = $stmt->fetch();
    // Jika bukunya ada, simpan nama file covernya
    if ($row) $img = $row['image'];

    // Hapus buku dari database (like dan item keranjang ikut terhapus lewat foreign key)
    $pdo->prepare("DELETE FROM books WHERE id = ?")->execute([$id]);

    // Hapus file cover dari folder upload, kecuali gambar bawaan no-image.png
    if ($img && $img !== 'no-image.png' && file_exists(UPLOAD_DIR . $img)) {
        // Tanda @ menyembunyikan warning kalau file gagal dihapus
        @unlink(UPLOAD_DIR . $img);
    }
    // Pesan sukses untuk ditampilkan setelah redirect
    flash('success', 'Buku berhasil dihapus.');
    // Muat ulang halaman daftar buku
    header('Location: ' . BASE_URL . '/books.php');
    // Hentikan script setelah redirect
    exit;
}

// Kata kunci pencarian dari kotak cari (kosong jika tidak ada)
$q = trim($_GET['q'] ?? '');
// Query utama: semua buku + nama genre + jumlah like + jumlah terjual
// like_count = jumlah like buku ini (dasar Trending now)
// sold_count = total eksemplar terjual; hanya pesanan paid/shipped/completed (dasar Best seller)
// LEFT JOIN agar buku tanpa genre tetap tampil
$sql = "SELECT b.*, c.name AS category_name,
    (SELECT COUNT(*) FROM book_likes l WHERE l.book_id = b.id) AS like_count,
    (SELECT COALESCE(SUM(oi.quantity),0) FROM order_items oi JOIN orders o ON o.id = oi.order_id
      WHERE oi.book_id = b.id AND o.status IN ('paid','shipped','completed')) AS sold_count
  FROM books b LEFT JOIN categories c ON b.category_id = c.id";
// Daftar nilai untuk placeholder (?) pada query
$params = [];
// Jika admin mengetik kata kunci, tambahkan filter judul/penulis
if ($q !== '') {
    // Cari kata kunci di judul ATAU penulis
    $sql .= " WHERE b.title LIKE ? OR b.author LIKE ?";
    // Nilai untuk placeholder judul (% = cocok sebagian)
    $params[] = "%$q%";
    // Nilai untuk placeholder penulis
    $params[] = "%$q%";
}
// Urutkan dari buku yang paling baru ditambahkan
$sql .= " ORDER BY b.created_at DESC";
// Siapkan query
$stmt = $pdo->prepare($sql);
// Jalankan query dengan parameter pencarian
$stmt->execute($params);
// Ambil semua hasil sebagai array
$books = $stmt->fetchAll();

// Judul tab browser
$page_title = 'Kelola Buku';
// Memuat header + sidebar admin
require_once 'includes/header.php';
?>

<?php // Bar atas: judul halaman dan tombol tambah buku ?>
<div class="admin-topbar">
  <h1 style="margin:0;">Kelola Buku</h1>
  <a href="<?= BASE_URL ?>/add_book.php" class="btn btn-primary">+ Tambah Buku</a>
</div>

<?php // Form pencarian buku (dikirim dengan GET, tekan Enter untuk mencari) ?>
<form method="get" style="margin-bottom:16px;max-width:320px;">
  <?php // Kotak cari; value mempertahankan kata kunci yang sudah diketik ?>
  <input type="text" name="q" placeholder="Cari judul / penulis..." value="<?= htmlspecialchars($q) ?>" style="width:100%;padding:8px 12px;border-radius:6px;border:1px solid #ddd;">
</form>

<?php // Jika tidak ada buku, tampilkan pesan kosong ?>
<?php if (empty($books)): ?>
  <div class="empty">Belum ada buku. <a href="<?= BASE_URL ?>/add_book.php">Tambah buku pertama</a></div>
<?php else: ?>
  <?php // Tabel daftar buku ?>
  <table class="data-table">
    <?php // Judul kolom tabel ?>
    <thead><tr><th>Cover</th><th>Judul</th><th>Penulis</th><th>Genre</th><th>Harga</th><th>Stok</th><th>Terjual</th><th>Like</th><th>Aksi</th></tr></thead>
    <tbody>
    <?php // Ulangi satu baris tabel untuk setiap buku ?>
    <?php foreach ($books as $b): ?>
      <tr>
        <?php // Gambar cover kecil ?>
        <td><img src="<?= book_image_url($b['image']) ?>" style="width:36px;height:50px;object-fit:cover;border-radius:4px;"></td>
        <?php // Judul (htmlspecialchars mencegah XSS) ?>
        <td><?= htmlspecialchars($b['title']) ?></td>
        <?php // Penulis ?>
        <td><?= htmlspecialchars($b['author']) ?></td>
        <?php // Nama genre; tanda "-" jika buku belum punya genre ?>
        <td><?= htmlspecialchars($b['category_name'] ?? '-') ?></td>
        <?php // Harga dalam format rupiah ?>
        <td><?= rupiah($b['price']) ?></td>
        <?php // Sisa stok ?>
        <td><?= $b['stock'] ?></td>
        <?php // Jumlah terjual ?>
        <td><?= (int)$b['sold_count'] ?></td>
        <?php // Jumlah like ?>
        <td><?= (int)$b['like_count'] ?></td>
        <?php // Kolom aksi: Edit dan Hapus, tidak boleh turun baris ?>
        <td style="white-space:nowrap;">
          <?php // Tombol menuju halaman edit buku ini ?>
          <a href="<?= BASE_URL ?>/edit_book.php?id=<?= $b['id'] ?>" class="btn btn-outline" style="padding:5px 10px;font-size:12px;">Edit</a>
          <?php // Form hapus; muncul konfirmasi browser sebelum dikirim ?>
          <form method="post" style="display:inline;" onsubmit="return confirm('Hapus buku ini?');">
            <?php // Penanda aksi hapus untuk blok di atas ?>
            <input type="hidden" name="action" value="delete">
            <?php // ID buku yang dihapus ?>
            <input type="hidden" name="id" value="<?= $b['id'] ?>">
            <?php // Tombol hapus ?>
            <button type="submit" class="btn btn-danger" style="padding:5px 10px;font-size:12px;">Hapus</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php // Memuat footer halaman ?>
<?php require_once 'includes/footer.php'; ?>
