<?php
// Panel "Kelola genre" yang disisipkan di bawah dropdown genre pada form Tambah/Edit Buku.
// Memakai <div> (bukan <form>) karena tidak boleh ada form di dalam form. Semua aksi lewat AJAX
// ke genres_api.php, jadi data yang sudah diketik di form buku tidak hilang.
// Syarat: <select name="category_id"> harus ada di halaman yang memuat file ini.
?>
<?php // Tombol untuk membuka/menutup panel ?>
<button type="button" id="gm-toggle" class="btn btn-outline" style="margin-top:8px;padding:5px 10px;font-size:12px;">Kelola genre</button>

<?php // Panel kelola genre; tersembunyi sampai tombol di atas ditekan ?>
<div id="gm-panel" hidden style="margin-top:10px;padding:14px;border:1px solid #e4e4e4;border-radius:8px;background:#fafafa;">
  <?php // Baris tambah genre baru ?>
  <div style="display:flex;gap:8px;">
    <input type="text" id="gm-new" maxlength="100" placeholder="Nama genre baru" style="flex:1;">
    <button type="button" id="gm-add" class="btn btn-primary" style="padding:6px 12px;font-size:13px;">Tambah</button>
  </div>
  <?php // Tempat pesan error / sukses ?>
  <p id="gm-msg" style="margin:8px 0 0;font-size:13px;min-height:1em;"></p>
  <?php // Daftar genre yang sudah ada (diisi lewat JavaScript) ?>
  <ul id="gm-list" style="list-style:none;margin:8px 0 0;padding:0;"></ul>
</div>

<script>
(function () {
  // Elemen-elemen yang dipakai
  var select = document.querySelector('select[name="category_id"]');
  var panel  = document.getElementById('gm-panel');
  var list   = document.getElementById('gm-list');
  var msg    = document.getElementById('gm-msg');
  var input  = document.getElementById('gm-new');
  var api    = '<?= BASE_URL ?>/genres_api.php';
  var loaded = false; // daftar baru dimuat saat panel pertama kali dibuka

  // Tampilkan pesan; isError = true memberi warna merah, selain itu hijau
  function say(text, isError) {
    msg.textContent = text || '';
    msg.style.color = isError ? '#c0392b' : '#2e7d4f';
  }

  // Kirim aksi ke genres_api.php lalu jalankan callback dengan hasil JSON
  function call(data, done) {
    var body = new URLSearchParams(data).toString();
    fetch(api, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.ok) { say(d.error || 'Terjadi kesalahan.', true); return; }
        done(d);
      })
      .catch(function () { say('Gagal terhubung ke server.', true); });
  }

  // Bangun ulang pilihan dropdown, pertahankan pilihan lama (atau pilih genre baru)
  function syncSelect(genres, selectId) {
    var current = selectId ? String(selectId) : select.value;
    select.innerHTML = '';
    var first = document.createElement('option');
    first.value = ''; first.textContent = '-- Pilih Genre --';
    select.appendChild(first);
    genres.forEach(function (g) {
      var o = document.createElement('option');
      o.value = g.id; o.textContent = g.name;
      select.appendChild(o);
    });
    select.value = current; // jika genre terpilih sudah dihapus, otomatis kembali ke kosong
  }

  // Satu baris genre: nama + tombol Edit + tombol Hapus
  function row(g) {
    var li = document.createElement('li');
    li.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 0;border-top:1px solid #eee;';

    var label = document.createElement('span');
    label.style.flex = '1';
    label.textContent = g.name + ' (' + g.book_count + ' buku)';

    var edit = document.createElement('button');
    edit.type = 'button'; edit.className = 'btn btn-outline'; edit.textContent = 'Edit';
    edit.style.cssText = 'padding:4px 9px;font-size:12px;';
    edit.onclick = function () { editRow(li, g); };

    var del = document.createElement('button');
    del.type = 'button'; del.className = 'btn btn-danger'; del.textContent = 'Hapus';
    del.style.cssText = 'padding:4px 9px;font-size:12px;';
    del.onclick = function () {
      if (!confirm('Hapus genre "' + g.name + '"? ' + g.book_count + ' buku akan menjadi tanpa genre.')) return;
      call({ action: 'delete', id: g.id }, function (d) { say('Genre dihapus.'); render(d.genres); syncSelect(d.genres); });
    };

    li.appendChild(label); li.appendChild(edit); li.appendChild(del);
    return li;
  }

  // Ubah baris menjadi input untuk mengganti nama genre
  function editRow(li, g) {
    li.innerHTML = '';
    var field = document.createElement('input');
    field.type = 'text'; field.value = g.name; field.maxLength = 100; field.style.flex = '1';

    var save = document.createElement('button');
    save.type = 'button'; save.className = 'btn btn-primary'; save.textContent = 'Simpan';
    save.style.cssText = 'padding:4px 9px;font-size:12px;';
    save.onclick = function () {
      call({ action: 'edit', id: g.id, name: field.value }, function (d) { say('Genre diperbarui.'); render(d.genres); syncSelect(d.genres); });
    };

    var cancel = document.createElement('button');
    cancel.type = 'button'; cancel.className = 'btn btn-outline'; cancel.textContent = 'Batal';
    cancel.style.cssText = 'padding:4px 9px;font-size:12px;';
    cancel.onclick = function () { li.replaceWith(row(g)); say(''); };

    // Enter menyimpan (dan tidak ikut mengirim form buku)
    field.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); save.click(); } });

    li.appendChild(field); li.appendChild(save); li.appendChild(cancel);
    field.focus();
  }

  // Gambar ulang seluruh daftar genre
  function render(genres) {
    list.innerHTML = '';
    if (!genres.length) {
      var empty = document.createElement('li');
      empty.style.cssText = 'color:#888;font-size:13px;padding:6px 0;';
      empty.textContent = 'Belum ada genre.';
      list.appendChild(empty);
      return;
    }
    genres.forEach(function (g) { list.appendChild(row(g)); });
  }

  // Tombol "Kelola genre": buka/tutup panel, muat daftar saat pertama dibuka
  document.getElementById('gm-toggle').onclick = function () {
    panel.hidden = !panel.hidden;
    if (!panel.hidden && !loaded) {
      call({ action: 'list' }, function (d) { loaded = true; render(d.genres); });
    }
  };

  // Tombol "Tambah": simpan genre baru, lalu langsung pilih di dropdown
  function add() {
    call({ action: 'add', name: input.value }, function (d) {
      say('Genre ditambahkan dan dipilih.');
      input.value = '';
      loaded = true;
      render(d.genres);
      syncSelect(d.genres, d.new_id);
    });
  }
  document.getElementById('gm-add').onclick = add;
  // Enter di kotak genre baru = Tambah (bukan kirim form buku)
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); add(); } });
})();
</script>
