<?php
require_once 'config.php';

$wishIds = wish_ids($pdo);

// Logika section beranda (otomatis, tidak lagi dipilih manual oleh admin):
//  - What's new   : buku terbaru, urut tanggal ditambahkan (admin menambah buku -> otomatis masuk di sini)
//  - Best seller  : urut jumlah buku terjual terbanyak (hanya pesanan paid/shipped/completed)
//  - Trending now : urut jumlah like terbanyak
function fetch_books($pdo, $where, $order, $limit = 6) {
    $limit = (int)$limit;
    $stmt = $pdo->query("SELECT * FROM (" . books_stats_sql() . ") t $where ORDER BY $order LIMIT $limit");
    return $stmt->fetchAll();
}

$newBooks    = fetch_books($pdo, '', 't.created_at DESC, t.id DESC');
$bestSellers = fetch_books($pdo, 'WHERE t.sold_count > 0', 't.sold_count DESC, t.created_at DESC');
$trending    = fetch_books($pdo, 'WHERE t.like_count > 0', 't.like_count DESC, t.created_at DESC');

// buku unggulan untuk hero (buku terbaru)
$stmt = $pdo->query("SELECT * FROM books ORDER BY created_at DESC LIMIT 1");
$bannerBook = $stmt->fetch();

function render_book_row($books, $wishIds, $class = 'book-grid', $emptyMsg = 'Belum ada buku di bagian ini.') {
    if (empty($books)) {
        echo '<div class="empty"><p>' . $emptyMsg . '</p></div>';
        return;
    }
    echo '<div class="' . $class . '">';
    foreach ($books as $b) render_book_card($b, $wishIds);
    echo '</div>';
}

$page_title = 'Home';
require_once 'includes/header.php';
?>

<section class="hero">
  <div>
    <h1>Bacaan berikutnya ada di sini.</h1>
    <p>Novel, pengembangan diri, dan buku populer lainnya. Pesan hari ini, kami antar ke rumahmu.</p>
    <div class="hero-cta">
      <a href="<?= BASE_URL ?>/category.php" class="btn btn-primary">Lihat semua buku</a>
      <?php if (is_logged_in()): ?>
        <a href="<?= BASE_URL ?>/wishlist.php" class="btn btn-outline">Buka wishlist</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/register.php" class="btn btn-outline">Buat akun</a>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($bannerBook): ?>
  <div class="hero-art">
    <div class="arch">
      <img src="<?= book_image_url($bannerBook['image']) ?>" alt="Sampul <?= htmlspecialchars($bannerBook['title']) ?>">
      <div class="sticker">
        <b>Baru</b>
      </div>
    </div>
    <div class="hero-cap">
      <h2><?= htmlspecialchars($bannerBook['title']) ?></h2>
      <p class="muted"><?= htmlspecialchars($bannerBook['author']) ?> &middot; <?= rupiah($bannerBook['price']) ?></p>
      <a href="<?= BASE_URL ?>/book_detail.php?id=<?= $bannerBook['id'] ?>">Lihat buku ini</a>
    </div>
  </div>
  <?php endif; ?>
</section>

<section>
  <div class="sec-head"><h2>What's new</h2><a href="<?= BASE_URL ?>/category.php">Semua buku</a></div>
  <?php render_book_row($newBooks, $wishIds); ?>
</section>

<section>
  <div class="sec-head"><h2>Best seller</h2></div>
  <?php if (empty($bestSellers)): ?>
    <div class="empty"><p>Belum ada buku yang terjual.</p></div>
  <?php else: ?>
  <ol class="rank">
    <?php foreach ($bestSellers as $i => $b): $url = BASE_URL . '/book_detail.php?id=' . $b['id']; ?>
    <li>
      <span class="rank-no"><?= $i + 1 ?></span>
      <a class="cover" href="<?= $url ?>"><img src="<?= book_image_url($b['image']) ?>" alt="Sampul <?= htmlspecialchars($b['title']) ?>" loading="lazy"></a>
      <div>
        <a class="book-title" href="<?= $url ?>"><?= htmlspecialchars($b['title']) ?></a>
        <p class="book-author"><?= htmlspecialchars($b['author']) ?></p>
        <div class="price"><strong><?= rupiah($b['price']) ?></strong><span class="sold-tag"><?= (int)$b['sold_count'] ?> terjual</span></div>
      </div>
      <form method="post" action="<?= BASE_URL ?>/cart.php">
        <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
        <input type="hidden" name="action" value="add">
        <button type="submit" class="btn-icon" aria-label="Tambah <?= htmlspecialchars($b['title']) ?> ke keranjang" <?= $b['stock'] <= 0 ? 'disabled' : '' ?>><?= icon('plus') ?></button>
      </form>
    </li>
    <?php endforeach; ?>
  </ol>
  <?php endif; ?>
</section>

<section>
  <div class="sec-head"><h2>Trending now</h2></div>
  <?php render_book_row($trending, $wishIds, 'scroller', 'Belum ada buku yang disukai. Tekan ikon hati di buku favoritmu!'); ?>
</section>

<?php require_once 'includes/footer.php'; ?>
