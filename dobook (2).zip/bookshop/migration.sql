-- ============================================================
-- MIGRASI DOBOOK: fitur Like (Trending), Best Seller, & Genre
-- Jalankan sekali di phpMyAdmin (tab SQL) pada database `bookshop`.
-- Aman dijalankan berulang kali.
-- ============================================================

-- 1) Tabel like buku (dasar urutan "Trending now")
CREATE TABLE IF NOT EXISTS `book_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_like` (`user_id`,`book_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `book_likes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `book_likes_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 2) Kolom pesanan yang dipakai checkout.php (kalau database kamu masih dari dump lama)
ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `recipient_name` varchar(100) DEFAULT NULL;
ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `phone` varchar(20) DEFAULT NULL;
ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `address` text DEFAULT NULL;
ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `payment_proof` varchar(255) DEFAULT NULL;

-- 3) Index agar query Best Seller cepat
ALTER TABLE `books` ADD INDEX IF NOT EXISTS `idx_created_at` (`created_at`);
