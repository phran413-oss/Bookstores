# DOBOOK - Website Toko Buku (PHP + MySQL + XAMPP)

Website toko buku sederhana dengan 2 role akun (Admin & User), fitur wishlist,
keranjang belanja, checkout, sampai struk/resi transaksi.

## 📁 Struktur Folder
```
bookshop/
├── assets/css/         -> style.css (tampilan sesuai mockup)
├── assets/images/      -> gambar, termasuk uploads/ untuk cover buku
├── includes/           -> header & footer yang dipakai halaman user
├── config.php          -> koneksi database & fungsi helper
├── bookshop.sql        -> struktur + data awal database
├── setup.php           -> membuat akun demo admin & user (jalankan sekali)
├── index.php           -> Home
├── login.php / register.php / logout.php
├── category.php        -> daftar buku / pencarian / filter kategori
├── book_detail.php
├── wishlist.php
├── like.php            -> endpoint like/unlike buku (AJAX)
├── migration.sql       -> update database lama (tabel book_likes)
├── cart.php
├── checkout.php
├── receipt.php         -> struk/resi setelah checkout
└── orders.php          -> riwayat pesanan user
```

## 🚀 Cara Instalasi di XAMPP

1. **Copy folder project**
   Salin seluruh folder `bookshop` ini ke dalam folder `htdocs` XAMPP kamu, contoh:
   `C:\xampp\htdocs\bookshop`

2. **Jalankan Apache & MySQL**
   Buka XAMPP Control Panel, klik **Start** pada Apache dan MySQL.

3. **Buat database**
   - Buka `http://localhost/phpmyadmin`
   - Klik tab **Import**
   - Pilih file `bookshop.sql` dari folder project, lalu klik **Go**
   - Database `bookshop` beserta tabel dan contoh buku akan otomatis dibuat

4. **Cek konfigurasi**
   Buka file `config.php`, pastikan bagian ini sesuai dengan XAMPP kamu (default XAMPP biasanya sudah pas, tidak perlu diubah):
   ```php
   $DB_HOST = 'localhost';
   $DB_NAME = 'bookshop';
   $DB_USER = 'root';
   $DB_PASS = '';
   ```
   Jika nama folder project kamu di `htdocs` BUKAN `bookshop`, ubah baris ini juga:
   ```php
   define('BASE_URL', '/bookshop'); // ganti sesuai nama folder kamu
   ```

5. **Buat akun demo**
   Buka di browser: `http://localhost/bookshop/setup.php`
   Ini akan otomatis membuat 2 akun:
   - **Admin** → email: `admin@bookshop.com` — password: `admin123`
   - **User** → email: `user@bookshop.com` — password: `user123`

   Setelah itu, sebaiknya hapus file `setup.php` supaya tidak bisa diakses orang lain.

6. **Buka website**
   `http://localhost/bookshop/index.php`

## 👤 Web Admin (terpisah)
Admin memakai web sendiri di folder `bookshop-admin` (salin ke `htdocs` sejajar
dengan `bookshop`), buka `http://localhost/bookshop-admin/login.php`. Sesi login
admin dan user terpisah. Admin bisa:
- Tambah / edit / hapus buku (upload cover, harga, stok, genre)
- Kelola Genre (`genres.php`): tambah, edit nama, dan hapus genre
  (genre dipakai sebagai filter di halaman Books pada web toko)
- Melihat semua transaksi & mengubah status pesanan (pending → paid → shipped → completed)
- Melihat statistik ringkas (total buku, user, transaksi, pendapatan)

Akun role `user` (hasil daftar lewat `register.php`) hanya bisa belanja di web toko.

## 🏠 Section Beranda (otomatis)
- **What's new** : setiap admin menambah buku baru, buku itu otomatis masuk (urut terbaru).
- **Best seller**: diurutkan dari jumlah eksemplar terjual terbanyak. Hanya pesanan
  berstatus *Lunas / Dikirim / Selesai* yang dihitung (pending & dibatalkan tidak).
- **Trending now**: diurutkan dari jumlah like terbanyak. User yang login menekan ikon
  hati (♥) di kartu buku atau halaman detail; tekan lagi untuk batal like (1 user = 1 like per buku).

> Database lama: jalankan `migration.sql` sekali di phpMyAdmin (membuat tabel `book_likes`).
> Instalasi baru: cukup import `bookshop.sql` (sudah termasuk).

## 🛒 Alur Transaksi User
1. User login / daftar akun baru
2. Cari buku lewat search bar atau menu **Books** (bisa filter kategori)
3. Klik ♡ untuk simpan ke **Wishlist**, atau **+ Add to Cart**
4. Buka halaman **Cart**, atur jumlah, lalu klik **Checkout**
5. Pilih metode pembayaran, klik **Bayar Sekarang**
6. Sistem otomatis membuat nomor invoice, mengurangi stok buku, dan menampilkan
   halaman **struk/resi** (bisa langsung dicetak / print)
7. Semua pesanan bisa dilihat lagi di menu **🧾 Pesanan**

## ⚠️ Catatan
- Pastikan folder `assets/images/uploads/` memiliki izin tulis (writable) agar
  admin bisa upload cover buku.
- Password disimpan ter-enkripsi (bcrypt) menggunakan `password_hash()` PHP,
  bukan teks biasa.
- Ini adalah project belajar/demo — untuk produksi sebaiknya tambahkan validasi
  & keamanan tambahan (rate limiting, HTTPS, dsb).
