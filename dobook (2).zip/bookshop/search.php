<?php
// Endpoint saran pencarian (live search): dipanggil JS saat user mengetik di kotak cari.
require_once 'config.php';
header('Content-Type: application/json; charset=utf-8');

$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 1) { echo json_encode(['results' => [], 'total' => 0]); exit; }

// escape wildcard LIKE supaya "%" dan "_" yang diketik dicari apa adanya
$like = '%' . addcslashes($q, '\\%_') . '%';
$starts = addcslashes($q, '\\%_') . '%';

$cnt = $pdo->prepare("SELECT COUNT(*) FROM books WHERE title LIKE ? OR author LIKE ?");
$cnt->execute([$like, $like]);
$total = (int)$cnt->fetchColumn();

// judul yang diawali kata kunci diprioritaskan, lalu yang terbaru
$stmt = $pdo->prepare("SELECT id, title, author, price, image FROM books
    WHERE title LIKE ? OR author LIKE ?
    ORDER BY (title LIKE ?) DESC, created_at DESC LIMIT 6");
$stmt->execute([$like, $like, $starts]);

$results = [];
foreach ($stmt->fetchAll() as $b) {
    $results[] = [
        'title'  => $b['title'],
        'author' => $b['author'],
        'price'  => rupiah($b['price']),
        'image'  => book_image_url($b['image']),
        'url'    => BASE_URL . '/book_detail.php?id=' . (int)$b['id'],
    ];
}
echo json_encode(['results' => $results, 'total' => $total], JSON_UNESCAPED_UNICODE);
