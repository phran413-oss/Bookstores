(function () {
  var body = document.body;
  var base = body.dataset.base || '';
  var logged = body.dataset.logged === '1';

  // Live search: hasil muncul saat mengetik (tanpa Enter)
  (function () {
    var form = document.querySelector('form.search');
    if (!form) return;
    var input = form.querySelector('input[name="q"]');
    var box = document.createElement('div');
    box.className = 'search-results';
    box.hidden = true;
    form.appendChild(box);
    input.setAttribute('autocomplete', 'off');

    var timer = null, ctrl = null, active = -1;

    function esc(t) { var d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
    function close() { box.hidden = true; active = -1; }
    function items() { return box.querySelectorAll('a.sr-item'); }
    function setActive(i) {
      var list = items();
      if (!list.length) return;
      active = (i + list.length) % list.length;
      list.forEach(function (el, n) { el.classList.toggle('active', n === active); });
    }

    function render(d, q) {
      if (!d.results.length) {
        box.innerHTML = '<p class="sr-empty">Tidak ada buku untuk &ldquo;' + esc(q) + '&rdquo;</p>';
      } else {
        box.innerHTML = d.results.map(function (b) {
          return '<a class="sr-item" href="' + esc(b.url) + '"><img src="' + esc(b.image) + '" alt="">' +
            '<span class="sr-text"><strong>' + esc(b.title) + '</strong><small>' + esc(b.author) + '</small></span>' +
            '<span class="sr-price">' + esc(b.price) + '</span></a>';
        }).join('') +
        '<a class="sr-all" href="' + base + '/category.php?q=' + encodeURIComponent(q) + '">Lihat semua ' + d.total + ' hasil</a>';
      }
      box.hidden = false;
      active = -1;
    }

    function run() {
      var q = input.value.trim();
      if (!q) { close(); return; }
      if (ctrl) ctrl.abort();
      ctrl = window.AbortController ? new AbortController() : null;
      fetch(base + '/search.php?q=' + encodeURIComponent(q), ctrl ? { signal: ctrl.signal } : {})
        .then(function (r) { return r.json(); })
        .then(function (d) { if (input.value.trim() === q) render(d, q); })
        .catch(function () {});
    }

    input.addEventListener('input', function () {
      clearTimeout(timer);
      timer = setTimeout(run, 200); // jeda 200ms agar tidak query tiap huruf
    });
    input.addEventListener('focus', function () { if (input.value.trim() && box.innerHTML) box.hidden = false; });
    input.addEventListener('keydown', function (e) {
      if (box.hidden) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); setActive(active + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(active - 1); }
      else if (e.key === 'Escape') { close(); }
      else if (e.key === 'Enter' && active >= 0) { e.preventDefault(); items()[active].click(); }
    });
    document.addEventListener('click', function (e) { if (!form.contains(e.target)) close(); });
  })();

  // Bookmark / wishlist
  function toggleWish(btn) {
    btn.disabled = true;
    fetch(base + '/wishlist.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=toggle&book_id=' + encodeURIComponent(btn.dataset.wish)
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        btn.classList.toggle('active', d.wished);
        btn.setAttribute('aria-pressed', d.wished ? 'true' : 'false');
        var label = btn.querySelector('.wish-label');
        if (label) label.textContent = d.wished ? 'Tersimpan di wishlist' : 'Simpan ke wishlist';
        if (!d.wished && document.querySelector('[data-wishlist-page]')) location.reload();
      })
      .catch(function () {})
      .then(function () { btn.disabled = false; });
  }

  // Like (hati): memengaruhi urutan "Trending now"
  function toggleLike(btn) {
    btn.disabled = true;
    fetch(base + '/like.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'book_id=' + encodeURIComponent(btn.dataset.like)
    })
      .then(function (r) {
        if (r.status === 401) { location.href = base + '/login.php'; throw new Error('login'); }
        if (!r.ok) throw new Error('http ' + r.status);
        return r.json();
      })
      .then(function (d) {
        if (typeof d.liked === 'undefined') throw new Error('bad response');
        // sinkronkan semua tombol like untuk buku yang sama (kartu & detail)
        document.querySelectorAll('[data-like="' + btn.dataset.like + '"]').forEach(function (b) {
          b.classList.toggle('active', d.liked);
          b.setAttribute('aria-pressed', d.liked ? 'true' : 'false');
          var c = b.querySelector('.like-count');
          if (c) c.textContent = d.count;
        });
      })
      .catch(function (err) {
        if (err && err.message === 'login') return;
        alert('Like gagal disimpan (' + (err && err.message) + '). Pastikan file like.php ada dan tabel book_likes sudah dibuat (jalankan migration.sql).');
      })
      .then(function () { btn.disabled = false; });
  }

  document.addEventListener('click', function (e) {
    var l = e.target.closest('[data-like]');
    if (l) {
      e.preventDefault();
      if (!logged) { location.href = base + '/login.php'; return; }
      toggleLike(l);
      return;
    }
    var w = e.target.closest('[data-wish]');
    if (w) {
      e.preventDefault();
      if (!logged) { location.href = base + '/login.php'; return; }
      toggleWish(w);
      return;
    }
    // Tombol − / + jumlah di keranjang
    var s = e.target.closest('[data-step]');
    if (s) {
      var form = s.closest('form');
      var input = form.querySelector('input[name=quantity]');
      var min = parseInt(input.min, 10) || 1;
      var max = parseInt(input.max, 10) || 999;
      var next = Math.min(max, Math.max(min, (parseInt(input.value, 10) || min) + parseInt(s.dataset.step, 10)));
      if (next !== parseInt(input.value, 10)) { input.value = next; form.submit(); }
    }
  });

  document.addEventListener('change', function (e) {
    if (e.target.matches('.qty input')) e.target.form.submit();
  });

  // Metode pembayaran: tampilkan rekening / QRIS / kolom unggah bukti
  function syncPay() {
    var cur = document.querySelector('input[name=payment_method]:checked');
    var val = cur ? cur.value : '';
    document.querySelectorAll('[data-pay-for]').forEach(function (el) {
      var show = el.dataset.payFor.split('|').indexOf(val) !== -1;
      el.hidden = !show;
      el.querySelectorAll('input[type=file]').forEach(function (i) { i.required = show; });
    });
  }
  document.querySelectorAll('input[name=payment_method]').forEach(function (r) {
    r.addEventListener('change', syncPay);
  });
  syncPay();

  // Tombol "Salin" nomor rekening
  document.addEventListener('click', function (e) {
    var c = e.target.closest('[data-copy]');
    if (!c || !navigator.clipboard) return;
    navigator.clipboard.writeText(c.dataset.copy).then(function () {
      var old = c.textContent;
      c.textContent = 'Tersalin';
      setTimeout(function () { c.textContent = old; }, 1500);
    });
  });

  // Pesan sukses hilang sendiri
  document.querySelectorAll('[data-autohide]').forEach(function (el) {
    setTimeout(function () { el.remove(); }, 3500);
  });
})();
