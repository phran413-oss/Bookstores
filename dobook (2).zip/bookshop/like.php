<?php
// Endpoint AJAX: like / unlike sebuah buku. Dipakai tombol hati di kartu & halaman detail.
require_once 'config.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'login']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method']);
    exit;
}

$bookId = (int)($_POST['book_id'] ?? 0);
$stmt = $pdo->prepare("SELECT id FROM books WHERE id = ?");
$stmt->execute([$bookId]);
if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(['error' => 'not_found']);
    exit;
}

$stmt = $pdo->prepare("SELECT id FROM book_likes WHERE user_id = ? AND book_id = ?");
$stmt->execute([$_SESSION['user_id'], $bookId]);
$existing = $stmt->fetch();

if ($existing) {
    $pdo->prepare("DELETE FROM book_likes WHERE id = ?")->execute([$existing['id']]);
    $liked = false;
} else {
    // INSERT IGNORE: aman kalau user menekan dua kali dengan cepat (ada UNIQUE user_id+book_id)
    $pdo->prepare("INSERT IGNORE INTO book_likes (user_id, book_id) VALUES (?,?)")->execute([$_SESSION['user_id'], $bookId]);
    $liked = true;
}

$stmt = $pdo->prepare("SELECT COUNT(*) FROM book_likes WHERE book_id = ?");
$stmt->execute([$bookId]);

echo json_encode(['liked' => $liked, 'count' => (int)$stmt->fetchColumn()]);
