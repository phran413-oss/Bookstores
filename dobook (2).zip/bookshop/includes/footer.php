</main>

<footer class="site-footer">
  <div class="foot">
    <div>
      <h2>About Us</h2>
      <p>Pusat buku terlengkap dan terpercaya. Kami siap mengantar ketenangan dan ilmu pengetahuan baru langsung ke depan pintu rumahmu.</p>
    </div>
    <div>
      <h3>Hubungi kami</h3>
      <p>Jl. Pelajar Indonesia No. 25, Kebayoran Baru, Jakarta Selatan, 12150</p>
      <p>WhatsApp: +62 812 3456 7890<br>Email: support@bookshop-example.com</p>
      <p>Senin - Sabtu, 09.00 - 20.00 WIB</p>
    </div>
    <div>
      <h3>Ikuti &amp; bantuan</h3>
      <ul>
        <li><a href="#">Instagram</a></li>
        <li><a href="#">YouTube</a></li>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Privacy Policy</a></li>
        <li><a href="#">Terms of Service</a></li>
      </ul>
    </div>
  </div>
  <div class="foot-base">&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All Rights Reserved.</div>
</footer>

<script src="<?= BASE_URL ?>/assets/js/app.js?v=<?= @filemtime(dirname(__DIR__) . '/assets/js/app.js') ?>"></script>
</body>
</html>
